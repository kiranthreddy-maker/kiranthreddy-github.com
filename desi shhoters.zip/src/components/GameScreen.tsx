import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "../game/engine";
import type { MatchResult, GameSettings } from "../game/engine";
import { charById } from "../game/characters";
import { audio } from "../game/audio";
import { saveHighScore } from "../game/highscores";
import { HighScoreTable, Portrait } from "./screens";

export function GameScreen({ charId, settings, onQuit, onSettingsChange }: {
  charId: string;
  settings: GameSettings;
  onQuit: () => void;
  onSettingsChange: (s: GameSettings) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [runKey, setRunKey] = useState(0);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [newBest, setNewBest] = useState(false);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setPaused(false);
    setResult(null);
    setNewBest(false);
    const game = new Game(canvas, charId, settingsRef.current, {
      onPauseChange: (p) => setPaused(p),
      onGameOver: (r) => {
        const { isNewBest } = saveHighScore({
          score: r.playerScore, kills: r.playerKills, charId,
          rank: r.playerRank, date: new Date().toISOString(),
        });
        setNewBest(isNewBest);
        setResult(r);
      },
    });
    gameRef.current = game;
    return () => game.destroy();
  }, [charId, runKey]);

  useEffect(() => {
    gameRef.current?.updateSettings(settings);
  }, [settings]);

  const resume = useCallback(() => {
    audio.sfx("click");
    gameRef.current?.setPaused(false);
    setPaused(false);
  }, []);
  const restart = useCallback(() => {
    audio.sfx("start");
    setRunKey((k) => k + 1);
  }, []);

  const btn = "btn-pixel font-pixel text-[11px] px-6 py-3.5 text-white w-full";
  const sel = charById(charId);

  return (
    <div className="relative w-full h-full bg-[#0b0614] overflow-hidden">
      <canvas ref={canvasRef} className="pixel-canvas block cursor-crosshair" />

      {/* ---- Pause menu ---- */}
      {paused && !result && (
        <div className="absolute inset-0 z-20 bg-black/70 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-[#170f28] border-2 border-[#ff3d8b] p-6 w-full max-w-sm animate-pop">
            <h2 className="font-pixel text-lg text-[#ffd400] neon-text text-center mb-1">PAUSED</h2>
            <p className="text-center text-[11px] text-[#9d8fc0] mb-5">chai break? ☕</p>
            <div className="flex flex-col gap-2.5">
              <button className={`${btn} bg-[#ff3d8b]`} onClick={resume}>▶ RESUME</button>
              <button className={`${btn} bg-[#6b2cbf]`} onClick={restart}>↻ RESTART MATCH</button>
              <div className="grid grid-cols-3 gap-2 my-1">
                {(["sfx", "music", "shake"] as const).map((k) => (
                  <button
                    key={k}
                    onClick={() => { audio.sfx("click"); onSettingsChange({ ...settings, [k]: !settings[k] }); }}
                    className={`text-[9px] font-pixel py-2 border-2 ${settings[k] ? "border-[#7dff9b] text-[#7dff9b]" : "border-[#3a2f52] text-[#6d5f8a]"}`}
                  >
                    {k.toUpperCase()}
                  </button>
                ))}
              </div>
              <button className={`${btn} bg-[#3a3344]`} onClick={() => { audio.sfx("click"); onQuit(); }}>✕ QUIT TO MENU</button>
            </div>
            <p className="text-center text-[10px] text-[#6d5f8a] mt-4">Esc to resume</p>
          </div>
        </div>
      )}

      {/* ---- Game over ---- */}
      {result && (
        <div className="absolute inset-0 z-20 bg-black/80 backdrop-blur-[3px] flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-[#170f28] border-2 border-[#ffd400] p-5 w-full max-w-lg animate-pop my-auto">
            <div className="text-center mb-4">
              <h2 className="font-pixel text-xl text-[#ffd400] neon-text">MATCH OVER!</h2>
              <div className="flex items-center justify-center gap-3 mt-3">
                <Portrait id={charId} scale={2} className="w-14 h-14" />
                <div className="text-left">
                  <div className="font-pixel text-[10px] text-[#24e0ff]">
                    {result.playerRank === 1 ? "🥇 MVP! RANK #1" : `RANK #${result.playerRank} / ${result.rows.length}`}
                  </div>
                  <div className="text-sm font-bold text-[#e8ddff]">{sel.name} • {result.playerKills} kills • {result.playerScore} pts</div>
                  {newBest && <div className="font-pixel text-[9px] text-[#7dff9b] mt-1 animate-pulse">★ NEW HIGH SCORE! ★</div>}
                </div>
              </div>
              <p className="text-[11px] text-[#9d8fc0] mt-2">
                {result.playerRank === 1 ? "OP bhai OP! Chat is spamming W 🙌" : result.playerRank <= 3 ? "Podium finish, thoda aur grind 💪" : "Bahut hard... next match pakka 😤"}
              </p>
            </div>

            <div className="bg-black/40 p-3 mb-3 max-h-52 overflow-y-auto">
              <div className="grid grid-cols-[1fr_auto_auto_auto] gap-x-4 gap-y-1 text-xs">
                <span className="text-[#6d5f8a] font-bold">PLAYER</span>
                <span className="text-[#6d5f8a] font-bold text-right">K</span>
                <span className="text-[#6d5f8a] font-bold text-right">D</span>
                <span className="text-[#6d5f8a] font-bold text-right">PTS</span>
                {result.rows.map((r, i) => (
                  <FragmentRow key={i} rank={i + 1} r={r} />
                ))}
              </div>
            </div>

            <div className="mb-4">
              <h3 className="font-pixel text-[10px] text-[#ff3d8b] mb-2">🏆 LOCAL HIGH SCORES</h3>
              <HighScoreTable highlightScore={result.playerScore} />
            </div>

            <div className="flex gap-2.5">
              <button className={`${btn} bg-[#ff3d8b]`} onClick={restart}>↻ REMATCH</button>
              <button className={`${btn} bg-[#3a3344]`} onClick={() => { audio.sfx("click"); onQuit(); }}>MENU</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FragmentRow({ rank, r }: { rank: number; r: MatchResult["rows"][number] }) {
  const c = charById(r.charId);
  return (
    <>
      <span className={`truncate ${r.isPlayer ? "text-[#7dff9b] font-bold" : "text-[#c9b8ff]"}`}>
        {rank}. {rank === 1 ? "👑 " : ""}{r.name} <span className="text-[#6d5f8a]">({c.name})</span>
      </span>
      <span className="text-right text-[#e8ddff]">{r.kills}</span>
      <span className="text-right text-[#9d8fc0]">{r.deaths}</span>
      <span className="text-right text-[#ffd400] font-bold">{r.score}</span>
    </>
  );
}
