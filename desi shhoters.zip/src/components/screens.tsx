import { useEffect, useRef, useState } from "react";
import { CHARACTERS, charById } from "../game/characters";
import type { CharDef } from "../game/characters";
import { renderPortrait } from "../game/sprites";
import { audio } from "../game/audio";
import { loadHighScores } from "../game/highscores";
import type { StoredSettings } from "../game/highscores";

// ---------- shared ----------
export function Portrait({ id, scale = 3, className = "" }: { id: string; scale?: number; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (ref.current) renderPortrait(ref.current, charById(id), scale);
  }, [id, scale]);
  return <canvas ref={ref} className={`pixel-canvas ${className}`} />;
}

function PixelButton({ children, onClick, color = "bg-pink-600", className = "" }: {
  children: React.ReactNode; onClick: () => void; color?: string; className?: string;
}) {
  return (
    <button
      onClick={() => { audio.unlock(); audio.sfx("click"); onClick(); }}
      className={`btn-pixel font-pixel text-xs md:text-sm px-6 py-4 ${color} text-white tracking-wider ${className}`}
    >
      {children}
    </button>
  );
}

const FLOATIES = ["🎮", "☕", "🛺", "🍌", "💀", "😂", "🔥", "📶", "🩴", "🐸", "💣", "🎤"];

export function ArenaBackdrop() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#2a1050_0%,#0b0614_65%)]" />
      <div className="absolute inset-0 opacity-40 bg-[linear-gradient(rgba(255,61,139,0.07)_1px,transparent_1px),linear-gradient(90deg,rgba(36,224,255,0.07)_1px,transparent_1px)] bg-[size:44px_44px]" />
      {FLOATIES.map((f, i) => (
        <div
          key={i}
          className="absolute text-2xl md:text-4xl opacity-20 animate-floaty"
          style={{
            left: `${(i * 83) % 95}%`,
            top: `${(i * 41 + 13) % 90}%`,
            animationDelay: `${i * 0.45}s`,
            animationDuration: `${3.4 + (i % 4)}s`,
          }}
        >
          {f}
        </div>
      ))}
      <div className="absolute inset-0 scanlines" />
    </div>
  );
}

// ---------- Main menu ----------
export function MainMenu({ onNav }: { onNav: (s: string) => void }) {
  const scores = loadHighScores();
  const best = scores[0];
  return (
    <div className="relative h-full flex flex-col items-center justify-center gap-3 px-4">
      <ArenaBackdrop />
      <div className="relative z-10 flex flex-col items-center animate-pop">
        <div className="text-4xl md:text-6xl mb-3">🛺💥🎮</div>
        <h1 className="font-pixel text-2xl md:text-5xl text-[#ff3d8b] neon-text text-center leading-relaxed">
          DESI MEME
        </h1>
        <h1 className="font-pixel text-2xl md:text-5xl text-[#24e0ff] neon-cyan-text text-center leading-relaxed mb-2">
          ARENA
        </h1>
        <p className="text-[#c9b8ff] text-sm md:text-base font-semibold mb-6 text-center">
          15 fighters • gully streets • chai-fueled chaos ☕🔥
        </p>
        <div className="flex flex-col gap-3 w-64">
          <PixelButton color="bg-[#ff3d8b]" onClick={() => onNav("chars")}>▶ PLAY</PixelButton>
          <PixelButton color="bg-[#6b2cbf]" onClick={() => onNav("charsView")}>CHARACTERS</PixelButton>
          <PixelButton color="bg-[#1d6fd1]" onClick={() => onNav("howto")}>HOW TO PLAY</PixelButton>
          <PixelButton color="bg-[#3a3344]" onClick={() => onNav("settings")}>SETTINGS</PixelButton>
        </div>
        {best && (
          <div className="mt-6 bg-black/50 border-2 border-[#ffd400]/50 px-5 py-2.5 text-center">
            <span className="font-pixel text-[10px] text-[#ffd400]">🏆 BEST: {best.score} pts • {best.kills} kills • {charById(best.charId).name}</span>
          </div>
        )}
      </div>
      <div className="relative z-10 text-xs text-[#6d5f8a] mt-4">v1.0 • local multiplayer-style arena vs AI lobby</div>
    </div>
  );
}

// ---------- Character select ----------
function StatBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-[9px] w-8 text-[#9d8fc0] font-bold">{label}</span>
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className={`w-2.5 h-1.5 ${i <= value ? color : "bg-[#2a2140]"}`} />
        ))}
      </div>
    </div>
  );
}

export function CharacterSelect({ selected, onSelect, onPlay, onBack, viewOnly }: {
  selected: string; onSelect: (id: string) => void; onPlay: () => void; onBack: () => void; viewOnly?: boolean;
}) {
  const sel = charById(selected);
  return (
    <div className="relative h-full flex flex-col px-3 py-3 md:px-6 md:py-4 overflow-hidden">
      <ArenaBackdrop />
      <div className="relative z-10 flex items-center justify-between mb-2">
        <button onClick={() => { audio.sfx("click"); onBack(); }} className="btn-pixel bg-[#3a3344] text-white font-pixel text-[10px] px-3 py-2">← BACK</button>
        <h2 className="font-pixel text-sm md:text-xl text-[#ffd400] neon-text">CHOOSE YOUR FIGHTER</h2>
        <div className="w-16" />
      </div>
      <div className="relative z-10 flex-1 min-h-0 flex flex-col md:flex-row gap-3">
        {/* grid */}
        <div className="flex-1 min-h-0 overflow-y-auto pr-1">
          <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-2">
            {CHARACTERS.map((c) => (
              <button
                key={c.id}
                onClick={() => { audio.unlock(); audio.sfx("click"); onSelect(c.id); }}
                className={`relative flex flex-col items-center p-2 border-2 transition-all ${
                  selected === c.id
                    ? "border-[#ff3d8b] bg-[#ff3d8b]/15 scale-[1.03] shadow-[0_0_16px_rgba(255,61,139,0.4)]"
                    : "border-[#3a2f52] bg-[#170f28]/80 hover:border-[#6d5f8a]"
                }`}
              >
                <Portrait id={c.id} scale={2} className="w-16 h-16" />
                <span className="text-[10px] font-bold text-[#e8ddff] leading-tight text-center mt-1">{c.name}</span>
                <span className="text-sm">{c.emoji}</span>
                {selected === c.id && <span className="absolute top-1 right-1 text-[#7dff9b] text-xs">✔</span>}
              </button>
            ))}
          </div>
        </div>
        {/* detail panel */}
        <div className="md:w-72 shrink-0 bg-[#170f28]/90 border-2 border-[#3a2f52] p-4 flex flex-row md:flex-col items-center gap-3 animate-slide-up" key={sel.id}>
          <Portrait id={sel.id} scale={3} className="w-24 h-24 md:w-32 md:h-32" />
          <div className="flex-1 md:text-center">
            <h3 className="font-pixel text-xs text-[#24e0ff] mb-1">{sel.name.toUpperCase()}</h3>
            <p className="text-[11px] italic text-[#9d8fc0] mb-2">“{sel.tagline}”</p>
            <div className="bg-black/40 p-2 mb-2 text-left">
              <div className="text-[11px] font-bold text-[#ffd400]">{sel.emoji} {sel.abilityName}</div>
              <div className="text-[10px] text-[#c9b8ff] leading-snug">{sel.abilityDesc}</div>
            </div>
            <div className="flex flex-col gap-1 items-start md:items-center">
              <StatBar label="SPD" value={sel.statSpeed} color="bg-[#24e0ff]" />
              <StatBar label="DMG" value={sel.statDamage} color="bg-[#ff5d4d]" />
              <StatBar label="HP" value={sel.statHealth} color="bg-[#7dff9b]" />
            </div>
            <div className="text-[10px] text-[#6d5f8a] mt-2">Weapon: {sel.weapon.name}</div>
          </div>
        </div>
      </div>
      {!viewOnly && (
        <div className="relative z-10 mt-3 flex justify-center">
          <PixelButton color="bg-[#ff3d8b]" className="w-full md:w-96 text-base" onClick={onPlay}>
            ⚔ LOCK IN & FIGHT
          </PixelButton>
        </div>
      )}
    </div>
  );
}

// ---------- How to play ----------
const CONTROLS: [string, string][] = [
  ["W A S D", "Move character"],
  ["Mouse", "Aim; auto-fires when lined up on an opponent"],
  ["Left Click", "Manual fire"],
  ["Right Click", "Use special ability"],
  ["Shift", "Sprint"],
  ["Ctrl", "Crouch / take cover (harder to hit)"],
  ["E", "Interact / pick up items"],
  ["R", "Reload"],
  ["Tab", "View scoreboard"],
  ["Esc", "Pause menu"],
];

export function HowToPlay({ onBack }: { onBack: () => void }) {
  return (
    <div className="relative h-full overflow-y-auto px-4 py-4">
      <ArenaBackdrop />
      <div className="relative z-10 max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => { audio.sfx("click"); onBack(); }} className="btn-pixel bg-[#3a3344] text-white font-pixel text-[10px] px-3 py-2">← BACK</button>
          <h2 className="font-pixel text-sm md:text-xl text-[#24e0ff] neon-cyan-text">HOW TO PLAY</h2>
          <div className="w-16" />
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-[#170f28]/90 border-2 border-[#3a2f52] p-4">
            <h3 className="font-pixel text-[11px] text-[#ffd400] mb-3">⌨ KEYBOARD CONTROLS</h3>
            <div className="flex flex-col gap-1.5">
              {CONTROLS.map(([k, v]) => (
                <div key={k} className="flex items-center gap-3">
                  <span className="font-pixel text-[9px] bg-[#2a2140] border border-[#4a3d69] px-2 py-1.5 text-[#7dff9b] min-w-24 text-center">{k}</span>
                  <span className="text-xs text-[#c9b8ff]">{v}</span>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-[#6d5f8a] mt-3">📱 On touch: left side = move stick, right side = aim & auto-fire, pink button = special.</p>
          </div>
          <div className="flex flex-col gap-4">
            <div className="bg-[#170f28]/90 border-2 border-[#3a2f52] p-4">
              <h3 className="font-pixel text-[11px] text-[#ffd400] mb-3">🎁 POWER-UPS</h3>
              <div className="flex flex-col gap-2 text-xs text-[#c9b8ff]">
                <div><span className="text-lg mr-2">☕</span><b className="text-[#7dff9b]">Cutting Chai</b> — restores up to 45 HP. Kadak!</div>
                <div><span className="text-lg mr-2">📦</span><b className="text-[#6db4ff]">Data Pack</b> — instant full ammo refill.</div>
                <div><span className="text-lg mr-2">📶</span><b className="text-[#ffd400]">WiFi Router</b> — speed boost for 4 seconds.</div>
              </div>
            </div>
            <div className="bg-[#170f28]/90 border-2 border-[#3a2f52] p-4">
              <h3 className="font-pixel text-[11px] text-[#ffd400] mb-3">🏆 THE RULES</h3>
              <ul className="text-xs text-[#c9b8ff] flex flex-col gap-1.5 list-disc pl-4">
                <li>Free-for-all vs 7 rivals in the gully. 2:30 on the clock.</li>
                <li>Kill = <b className="text-[#ffd400]">100 pts</b>, streaks add bonus. First to 15 kills ends it early.</li>
                <li>Use cover — crates, autos and thelas block bullets.</li>
                <li>Every fighter has a unique <b className="text-[#ff3d8b]">special (Right Click)</b>. Spam responsibly.</li>
                <li>Most points = MVP 👑. Get roasted in the kill feed otherwise.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- Settings ----------
function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => { audio.sfx("click"); onChange(!value); }}
      className="flex items-center justify-between w-full bg-[#170f28]/90 border-2 border-[#3a2f52] p-4 hover:border-[#6d5f8a] transition-colors"
    >
      <div className="text-left">
        <div className="font-pixel text-[11px] text-[#e8ddff]">{label}</div>
        <div className="text-[11px] text-[#6d5f8a] mt-1">{desc}</div>
      </div>
      <div className={`font-pixel text-[10px] px-3 py-2 ${value ? "bg-[#7dff9b] text-black" : "bg-[#2a2140] text-[#6d5f8a]"}`}>
        {value ? "ON" : "OFF"}
      </div>
    </button>
  );
}

export function Settings({ settings, onChange, onBack }: {
  settings: StoredSettings; onChange: (s: StoredSettings) => void; onBack: () => void;
}) {
  return (
    <div className="relative h-full px-4 py-4 overflow-y-auto">
      <ArenaBackdrop />
      <div className="relative z-10 max-w-md mx-auto">
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => { audio.sfx("click"); onBack(); }} className="btn-pixel bg-[#3a3344] text-white font-pixel text-[10px] px-3 py-2">← BACK</button>
          <h2 className="font-pixel text-sm md:text-xl text-[#ffd400] neon-text">SETTINGS</h2>
          <div className="w-16" />
        </div>
        <div className="flex flex-col gap-3">
          <Toggle label="SOUND FX" desc="Pew pew, chappal hits & pickup blips" value={settings.sfx} onChange={(v) => onChange({ ...settings, sfx: v })} />
          <Toggle label="MUSIC" desc="Lo-fi gully chiptune loop" value={settings.music} onChange={(v) => onChange({ ...settings, music: v })} />
          <Toggle label="SCREEN SHAKE" desc="Extra juice on hits & explosions" value={settings.shake} onChange={(v) => onChange({ ...settings, shake: v })} />
        </div>
      </div>
    </div>
  );
}

// ---------- High score table (shared with game over) ----------
export function HighScoreTable({ highlightScore }: { highlightScore?: number }) {
  const [scores] = useState(loadHighScores);
  if (!scores.length) return <div className="text-xs text-[#6d5f8a] text-center py-2">No matches played yet. Go make history! 🏏</div>;
  return (
    <div className="flex flex-col gap-1">
      {scores.map((s, i) => {
        const c: CharDef = charById(s.charId);
        const hl = highlightScore !== undefined && s.score === highlightScore;
        return (
          <div key={i} className={`flex items-center gap-2 px-2 py-1 text-xs ${hl ? "bg-[#ffd400]/15 border border-[#ffd400]/40" : "bg-black/30"}`}>
            <span className="font-pixel text-[9px] text-[#ffd400] w-6">{i + 1}.</span>
            <span className="text-base">{c.emoji}</span>
            <span className="text-[#c9b8ff] flex-1">{c.name}</span>
            <span className="text-[#9d8fc0]">{s.kills} kills</span>
            <span className="font-pixel text-[9px] text-[#7dff9b] w-16 text-right">{s.score}</span>
          </div>
        );
      })}
    </div>
  );
}
