export interface HighScore {
  score: number;
  kills: number;
  charId: string;
  rank: number;
  date: string;
}

const KEY = "dma_highscores_v1";

export function loadHighScores(): HighScore[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as HighScore[];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export function saveHighScore(entry: HighScore): { list: HighScore[]; isNewBest: boolean } {
  const list = loadHighScores();
  const isNewBest = list.length === 0 || entry.score > Math.max(...list.map((h) => h.score));
  list.push(entry);
  list.sort((a, b) => b.score - a.score);
  const trimmed = list.slice(0, 8);
  try {
    localStorage.setItem(KEY, JSON.stringify(trimmed));
  } catch {
    // storage unavailable
  }
  return { list: trimmed, isNewBest };
}

const SETTINGS_KEY = "dma_settings_v1";

export interface StoredSettings { sfx: boolean; music: boolean; shake: boolean }

export function loadSettings(): StoredSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { sfx: true, music: true, shake: true, ...JSON.parse(raw) };
  } catch {
    // ignore
  }
  return { sfx: true, music: true, shake: true };
}

export function saveSettings(s: StoredSettings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    // ignore
  }
}
