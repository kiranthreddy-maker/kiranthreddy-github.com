// ============ Tiny WebAudio synth for SFX + chiptune loop ============

export interface AudioSettings {
  sfx: boolean;
  music: boolean;
}

class AudioSys {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private musicTimer: number | null = null;
  private musicStep = 0;
  settings: AudioSettings = { sfx: true, music: true };

  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.16;
      this.musicGain.connect(this.master);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slide = 0, delay = 0) {
    if (!this.ctx || !this.master || !this.settings.sfx) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide !== 0) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, freq = 800, delay = 0) {
    if (!this.ctx || !this.master || !this.settings.sfx) return;
    const t = this.ctx.currentTime + delay;
    const len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
  }

  sfx(name: string) {
    switch (name) {
      case "shoot": this.tone(340 + Math.random() * 80, 0.07, "square", 0.11, -180); break;
      case "shoot2": this.tone(220 + Math.random() * 40, 0.09, "sawtooth", 0.1, -120); break;
      case "sniper": this.tone(140, 0.25, "sawtooth", 0.22, -90); this.noise(0.18, 0.2, 1600); break;
      case "hit": this.tone(180, 0.06, "square", 0.14, -60); break;
      case "hurt": this.tone(130, 0.14, "sawtooth", 0.2, -70); this.noise(0.1, 0.12, 500); break;
      case "kill": this.tone(520, 0.09, "square", 0.16); this.tone(660, 0.09, "square", 0.16, 0, 0.08); this.tone(880, 0.16, "square", 0.16, 0, 0.16); break;
      case "death": this.tone(400, 0.4, "sawtooth", 0.2, -320); this.noise(0.35, 0.18, 700); break;
      case "pickup": this.tone(660, 0.07, "square", 0.12); this.tone(990, 0.1, "square", 0.12, 0, 0.06); break;
      case "heal": this.tone(440, 0.1, "sine", 0.16); this.tone(550, 0.1, "sine", 0.16, 0, 0.09); this.tone(660, 0.14, "sine", 0.16, 0, 0.18); break;
      case "reload": this.tone(300, 0.05, "square", 0.1); this.tone(420, 0.05, "square", 0.1, 0, 0.12); break;
      case "explode": this.noise(0.45, 0.35, 900); this.tone(90, 0.4, "sine", 0.3, -50); break;
      case "special": this.tone(240, 0.12, "sawtooth", 0.18, 260); this.tone(480, 0.16, "square", 0.14, 300, 0.08); break;
      case "teleport": this.tone(900, 0.12, "sine", 0.16, -700); this.tone(300, 0.12, "sine", 0.14, 700, 0.06); break;
      case "stun": this.tone(760, 0.08, "square", 0.14, -40); this.tone(760, 0.08, "square", 0.12, -40, 0.1); this.tone(760, 0.08, "square", 0.1, -40, 0.2); break;
      case "click": this.tone(500, 0.05, "square", 0.12); break;
      case "start": this.tone(330, 0.1, "square", 0.16); this.tone(440, 0.1, "square", 0.16, 0, 0.1); this.tone(660, 0.22, "square", 0.18, 0, 0.2); break;
      case "over": this.tone(660, 0.14, "square", 0.16); this.tone(494, 0.14, "square", 0.16, 0, 0.14); this.tone(330, 0.3, "square", 0.18, 0, 0.28); break;
      case "empty": this.tone(160, 0.06, "square", 0.1); break;
    }
  }

  startMusic() {
    if (this.musicTimer !== null) return;
    const bass = [55, 55, 65.4, 55, 55, 55, 49, 52];
    const lead = [440, 0, 523, 0, 587, 523, 0, 659, 440, 0, 523, 0, 392, 0, 440, 0];
    this.musicStep = 0;
    this.musicTimer = window.setInterval(() => {
      if (!this.ctx || !this.musicGain || !this.settings.music) return;
      const t = this.ctx.currentTime;
      const s = this.musicStep;
      // bass
      if (s % 2 === 0) {
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = "triangle";
        o.frequency.value = bass[(s / 2) % 8];
        g.gain.setValueAtTime(0.5, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
        o.connect(g).connect(this.musicGain);
        o.start(t); o.stop(t + 0.25);
      }
      // lead
      const n = lead[s % 16];
      if (n > 0) {
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = "square";
        o.frequency.value = n;
        g.gain.setValueAtTime(0.1, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
        o.connect(g).connect(this.musicGain);
        o.start(t); o.stop(t + 0.16);
      }
      // hat
      if (s % 2 === 1 && this.settings.sfx) {
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = "square";
        o.frequency.value = 6000 + Math.random() * 2000;
        g.gain.setValueAtTime(0.015, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.03);
        o.connect(g).connect(this.musicGain);
        o.start(t); o.stop(t + 0.04);
      }
      this.musicStep++;
    }, 150);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

export const audio = new AudioSys();
