import type { CharDef } from "./characters";

// Procedural pixel chibi renderer. All drawing centered at (0,0), feet ~ y=16.
// Unit: 1 "pixel" = 2 canvas units at scale 1.

export interface SpritePose {
  frame: number; // walk cycle 0..1
  moving: boolean;
  flip: boolean; // facing left
  crouch: boolean;
  alpha: number;
  aim: number; // radians
  time: number;
}

function px(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, c: string) {
  ctx.fillStyle = c;
  ctx.fillRect(Math.round(x), Math.round(y), w, h);
}

export function drawShadow(ctx: CanvasRenderingContext2D, w = 22) {
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.beginPath();
  ctx.ellipse(0, 16, w / 2, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawBody(ctx: CanvasRenderingContext2D, d: CharDef, p: SpritePose, ox = 0, mini = false) {
  const s = mini ? 0.72 : 1;
  ctx.save();
  ctx.translate(ox, 0);
  ctx.scale(s, s);
  const bob = p.moving ? Math.sin(p.frame * Math.PI * 2) * 1.6 : Math.sin(p.time * 2.4) * 0.7;
  const legA = p.moving ? Math.sin(p.frame * Math.PI * 2) * 3 : 0;
  const crouchY = p.crouch ? 5 : 0;

  // legs
  px(ctx, -6, 8 + crouchY, 5, 8 - crouchY + legA * 0.4, "#221a2e");
  px(ctx, 1, 8 + crouchY, 5, 8 - crouchY - legA * 0.4, "#221a2e");
  px(ctx, -6, 14 + crouchY * 0.5 + legA * 0.4, 5, 3, "#0e0a16"); // shoes
  px(ctx, 1, 14 + crouchY * 0.5 - legA * 0.4, 5, 3, "#0e0a16");

  const by = -2 + bob * 0.5 + crouchY;
  // torso
  px(ctx, -8, by, 16, 11, d.body);
  px(ctx, -8, by + 8, 16, 3, d.body2);
  px(ctx, -8, by, 3, 11, d.body2); // side shade
  // arms
  px(ctx, -10, by + 1, 3, 8, d.body2);
  px(ctx, 7, by + 1, 3, 8, d.body2);

  const hy = by - 12;
  // head
  px(ctx, -7, hy, 14, 12, d.skin);
  // hair / headgear base
  px(ctx, -7, hy - 2, 14, 5, d.hair);
  px(ctx, -8, hy, 2, 6, d.hair);
  px(ctx, 6, hy, 2, 6, d.hair);
  // eyes (face direction)
  const ex = p.flip ? -3 : 0;
  px(ctx, -3 + ex, hy + 6, 2, 3, "#17131f");
  px(ctx, 3 + ex, hy + 6, 2, 3, "#17131f");

  // ---- per-character accessories ----
  switch (d.id) {
    case "rager": // big headset + angry brows
      px(ctx, -9, hy + 4, 3, 6, "#e63946");
      px(ctx, 6, hy + 4, 3, 6, "#e63946");
      px(ctx, -7, hy - 4, 14, 3, "#e63946");
      px(ctx, -4 + ex, hy + 4, 3, 2, "#7a0c14"); // brows
      px(ctx, 2 + ex, hy + 4, 3, 2, "#7a0c14");
      break;
    case "chaos": // hoodie up
      px(ctx, -8, hy - 3, 16, 5, d.body);
      px(ctx, -8, hy, 3, 10, d.body);
      px(ctx, 5, hy, 3, 10, d.body);
      px(ctx, -3, by + 2, 6, 4, "#ffe14d"); // drawstring patch
      break;
    case "roast": // slick hair + gold chain + mic hand
      px(ctx, -3, by + 1, 6, 2, "#ffd700");
      px(ctx, p.flip ? -13 : 9, by + 3, 4, 4, "#2b2b2b"); // mic
      px(ctx, p.flip ? -12 : 10, by + 7, 2, 4, "#555");
      break;
    case "glitch": { // neon bob + shades + antenna
      px(ctx, -8, hy - 3, 16, 6, d.hair);
      px(ctx, -8, hy + 2, 3, 8, d.hair);
      px(ctx, 5, hy + 2, 3, 8, d.hair);
      px(ctx, -6 + ex, hy + 5, 12, 3, "#f72585");
      const gl = Math.sin(p.time * 12) > 0.6;
      if (gl) px(ctx, -9, hy + 1, 2, 2, "#24e0ff");
      break;
    }
    case "chai": // army bandana + kettle backpack
      px(ctx, -7, hy - 2, 14, 4, "#3f4a22");
      px(ctx, -7, hy + 1, 3, 2, "#5b6b31");
      px(ctx, p.flip ? 7 : -11, by + 1, 4, 7, "#b9b3a8"); // kettle
      px(ctx, p.flip ? 9 : -12, by - 1, 2, 3, "#8f887c");
      break;
    case "meme": // frog bucket hat
      px(ctx, -9, hy - 3, 18, 4, "#38b000");
      px(ctx, -6, hy - 6, 12, 4, "#38b000");
      px(ctx, -4, hy - 6, 2, 2, "#fff");
      px(ctx, 2, hy - 6, 2, 2, "#fff");
      break;
    case "prank": // party crown
      px(ctx, -6, hy - 6, 12, 4, "#ffd400");
      px(ctx, -6, hy - 8, 2, 3, "#ffd400");
      px(ctx, -1, hy - 9, 2, 4, "#ffd400");
      px(ctx, 4, hy - 8, 2, 3, "#ffd400");
      break;
    case "sniper": // cap + scope eye
      px(ctx, -7, hy - 3, 14, 4, "#39431d");
      px(ctx, p.flip ? -12 : 6, hy - 2, 6, 3, "#39431d");
      px(ctx, 2 + ex, hy + 5, 5, 5, "#20242c");
      px(ctx, 3 + ex, hy + 6, 3, 3, "#ffe066");
      break;
    case "auto": // yellow helmet + meter
      px(ctx, -8, hy - 4, 16, 6, "#ffd400");
      px(ctx, -8, hy + 1, 16, 2, "#111827");
      px(ctx, -3, by + 2, 6, 5, "#111827");
      px(ctx, -2, by + 3, 4, 3, "#ffd400");
      break;
    case "sis": // long hair + heart tee + halo ring
      px(ctx, -9, hy - 2, 3, 16, d.hair);
      px(ctx, 6, hy - 2, 3, 16, d.hair);
      px(ctx, -2, by + 2, 2, 2, "#fff");
      px(ctx, 0, by + 2, 2, 2, "#fff");
      px(ctx, -1, by + 4, 2, 2, "#fff");
      break;
    case "gully": // backwards cap
      px(ctx, -7, hy - 4, 14, 4, "#124a8f");
      px(ctx, p.flip ? 6 : -11, hy - 3, 5, 3, "#124a8f");
      px(ctx, -3, by + 2, 6, 3, "#fff");
      break;
    case "emoji": // smiley on shirt
      px(ctx, -3, by + 2, 6, 6, "#ffdd57");
      px(ctx, -2, by + 3, 1, 2, "#111");
      px(ctx, 1, by + 3, 1, 2, "#111");
      px(ctx, -2, by + 6, 4, 1, "#111");
      break;
    case "rank": // sweatband + energy drink glow
      px(ctx, -7, hy + 1, 14, 3, "#ff3d8b");
      px(ctx, -3, by + 2, 6, 2, "#8d80ff");
      break;
    case "ghost": // hood + single glowing eye
      px(ctx, -8, hy - 3, 16, 6, "#5b6478");
      px(ctx, -8, hy + 2, 3, 9, "#5b6478");
      px(ctx, 5, hy + 2, 3, 9, "#5b6478");
      px(ctx, -1 + ex, hy + 5, 4, 4, "#24e0ff");
      break;
  }
  ctx.restore();
  return by;
}

export function drawGun(ctx: CanvasRenderingContext2D, d: CharDef, aim: number) {
  ctx.save();
  ctx.rotate(aim);
  const long = d.id === "sniper" ? 18 : 11;
  ctx.fillStyle = "#1c1826";
  ctx.fillRect(2, -2, long, 4);
  ctx.fillStyle = d.weapon.bulletColor;
  ctx.fillRect(long - 1, -1, 3, 2);
  if (d.id === "sniper") {
    ctx.fillStyle = "#39431d";
    ctx.fillRect(8, -4, 5, 2);
  }
  if (d.id === "chai") {
    ctx.fillStyle = "#b9b3a8";
    ctx.fillRect(3, -4, 6, 6);
  }
  ctx.restore();
}

export function drawFighterSprite(ctx: CanvasRenderingContext2D, d: CharDef, p: SpritePose) {
  ctx.save();
  ctx.globalAlpha = p.alpha;
  drawShadow(ctx, d.id === "duo" ? 30 : 22);
  if (d.id === "duo") {
    drawBody(ctx, d, p, p.flip ? 9 : -9, true);
    drawBody(ctx, d, p, p.flip ? -5 : 5, false);
  } else {
    drawBody(ctx, d, p, 0, false);
  }
  // gun at shoulder height
  ctx.save();
  ctx.translate(0, -1 + (p.crouch ? 5 : 0));
  drawGun(ctx, d, p.aim);
  ctx.restore();
  ctx.restore();
}

export function drawDeadSprite(ctx: CanvasRenderingContext2D, d: CharDef, t: number) {
  // squished spin-out
  const sq = Math.max(0.25, 1 - t * 1.4);
  ctx.save();
  ctx.globalAlpha = Math.max(0, 1 - t * 0.8);
  ctx.rotate(Math.min(t * 6, Math.PI / 2));
  ctx.scale(1 + t * 0.4, sq);
  drawBody(ctx, d, { frame: 0, moving: false, flip: false, crouch: false, alpha: 1, aim: 0, time: 0 }, 0, false);
  // X eyes
  ctx.fillStyle = "#17131f";
  ctx.font = "8px monospace";
  ctx.fillText("x x", -6, -8);
  ctx.restore();
}

export function renderPortrait(canvas: HTMLCanvasElement, d: CharDef, scale = 3) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  canvas.width = 44 * scale;
  canvas.height = 44 * scale;
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.save();
  ctx.translate(canvas.width / 2, canvas.height / 2 + 6 * scale);
  ctx.scale(scale, scale);
  drawFighterSprite(ctx, d, {
    frame: 0, moving: false, flip: false, crouch: false, alpha: 1, aim: -0.3, time: 1.2,
  });
  ctx.restore();
}
