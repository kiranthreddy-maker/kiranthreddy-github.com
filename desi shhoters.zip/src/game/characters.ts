// ============ DESI MEME ARENA — Character Roster ============

export interface WeaponDef {
  name: string;
  dmg: number;
  rate: number; // seconds between shots
  speed: number; // bullet speed px/s
  spread: number; // radians
  ammo: number;
  reload: number; // seconds
  range: number; // bullet lifetime distance
  bulletSize: number;
  bulletColor: string;
  pellets?: number;
  pierce?: boolean;
  splash?: number; // splash radius
}

export interface CharDef {
  id: string;
  name: string;
  tagline: string;
  emoji: string; // ability icon
  abilityName: string;
  abilityDesc: string;
  specialCd: number;
  // palette
  body: string; // outfit main
  body2: string; // outfit accent
  skin: string;
  hair: string;
  // stats 1..5 for UI bars
  statSpeed: number;
  statDamage: number;
  statHealth: number;
  // actual gameplay values
  maxHp: number;
  moveSpeed: number;
  weapon: WeaponDef;
}

export const CHARACTERS: CharDef[] = [
  {
    id: "rager", name: "Rager", tagline: "Keyboard todunga bhai!",
    emoji: "🎮", abilityName: "Controller Smash",
    abilityDesc: "Slams the ground — huge AoE damage + knockback around him.",
    specialCd: 8,
    body: "#d62828", body2: "#8f1010", skin: "#f0b184", hair: "#241417",
    statSpeed: 3, statDamage: 4, statHealth: 4,
    maxHp: 120, moveSpeed: 168,
    weapon: { name: "Rage SMG", dmg: 11, rate: 0.13, speed: 620, spread: 0.11, ammo: 28, reload: 1.3, range: 420, bulletSize: 3, bulletColor: "#ff5d4d" },
  },
  {
    id: "chaos", name: "Chaos Bhai", tagline: "Scene on hai!",
    emoji: "🍌", abilityName: "Banana Trap",
    abilityDesc: "Drops a banana peel that slips & stuns whoever steps on it.",
    specialCd: 6,
    body: "#f77f00", body2: "#b45309", skin: "#e0a370", hair: "#1c1917",
    statSpeed: 4, statDamage: 3, statHealth: 3,
    maxHp: 105, moveSpeed: 180,
    weapon: { name: "Chappal Launcher", dmg: 16, rate: 0.24, speed: 560, spread: 0.07, ammo: 16, reload: 1.4, range: 430, bulletSize: 4, bulletColor: "#ffc14d" },
  },
  {
    id: "duo", name: "Duo Twins", tagline: "2x trouble, 1x brain.",
    emoji: "👯", abilityName: "Twin Volley",
    abilityDesc: "Both twins unleash a rapid double-damage bullet storm.",
    specialCd: 10,
    body: "#0f9b8e", body2: "#0b6b62", skin: "#f0b184", hair: "#3a2a20",
    statSpeed: 3, statDamage: 4, statHealth: 3,
    maxHp: 110, moveSpeed: 165,
    weapon: { name: "Jodi Pistols", dmg: 9, rate: 0.2, speed: 600, spread: 0.05, ammo: 24, reload: 1.5, range: 440, bulletSize: 3, bulletColor: "#4dffe3", pellets: 2 },
  },
  {
    id: "roast", name: "Roast Master", tagline: "Aaj toh full roast hoga.",
    emoji: "🎤", abilityName: "Burn Wave",
    abilityDesc: "Drops a savage roast — stuns every enemy in a sound wave.",
    specialCd: 9,
    body: "#7b2cbf", body2: "#4c1580", skin: "#d69869", hair: "#120b16",
    statSpeed: 3, statDamage: 3, statHealth: 4,
    maxHp: 115, moveSpeed: 162,
    weapon: { name: "Bass Blaster", dmg: 15, rate: 0.26, speed: 540, spread: 0.06, ammo: 15, reload: 1.4, range: 400, bulletSize: 4, bulletColor: "#c77dff" },
  },
  {
    id: "glitch", name: "Glitch Queen", tagline: "Lag nahi, skill hai.",
    emoji: "⚡", abilityName: "Blink Teleport",
    abilityDesc: "Teleports a short distance toward the crosshair. Untouchable.",
    specialCd: 5,
    body: "#f72585", body2: "#7209b7", skin: "#f2c19a", hair: "#24e0ff",
    statSpeed: 5, statDamage: 3, statHealth: 2,
    maxHp: 90, moveSpeed: 196,
    weapon: { name: "Pixel Ray", dmg: 12, rate: 0.16, speed: 700, spread: 0.06, ammo: 20, reload: 1.2, range: 460, bulletSize: 3, bulletColor: "#ff4dd8" },
  },
  {
    id: "chai", name: "Chai Wala Commando", tagline: "Kadak chai, kadak aim.",
    emoji: "🫖", abilityName: "Kettle Splash",
    abilityDesc: "Lobs boiling chai — splash damage + burn in a big area.",
    specialCd: 7,
    body: "#606c38", body2: "#3f4a22", skin: "#c98a5b", hair: "#26170e",
    statSpeed: 3, statDamage: 4, statHealth: 4,
    maxHp: 125, moveSpeed: 158,
    weapon: { name: "Kettle Gun", dmg: 14, rate: 0.3, speed: 480, spread: 0.12, ammo: 12, reload: 1.6, range: 340, bulletSize: 5, bulletColor: "#d4a373", splash: 34 },
  },
  {
    id: "meme", name: "Meme Lord", tagline: "Template ready hai.",
    emoji: "🐸", abilityName: "Sticker Trap",
    abilityDesc: "Plants an explosive meme sticker. Step on it = instant ratio.",
    specialCd: 6,
    body: "#38b000", body2: "#217000", skin: "#f0b184", hair: "#57430b",
    statSpeed: 4, statDamage: 3, statHealth: 3,
    maxHp: 100, moveSpeed: 176,
    weapon: { name: "Ratio Rifle", dmg: 13, rate: 0.19, speed: 620, spread: 0.08, ammo: 22, reload: 1.3, range: 430, bulletSize: 3, bulletColor: "#9ef01a" },
  },
  {
    id: "prank", name: "Prank King", tagline: "It's just a prank bro!",
    emoji: "👻", abilityName: "Fake Death",
    abilityDesc: "Drops a fake corpse & turns invisible for 3 seconds.",
    specialCd: 11,
    body: "#ff70a6", body2: "#c9366f", skin: "#f2c19a", hair: "#1f1a24",
    statSpeed: 4, statDamage: 3, statHealth: 3,
    maxHp: 100, moveSpeed: 182,
    weapon: { name: "Party Popper", dmg: 12, rate: 0.17, speed: 600, spread: 0.09, ammo: 20, reload: 1.3, range: 400, bulletSize: 3, bulletColor: "#ff9ecb" },
  },
  {
    id: "sniper", name: "Desi Sniper", tagline: "Ek goli, ek lobby.",
    emoji: "🎯", abilityName: "Dhamaka Shot",
    abilityDesc: "Charged piercing mega-shot that goes through everything.",
    specialCd: 9,
    body: "#5c6b2f", body2: "#39431d", skin: "#d69869", hair: "#161410",
    statSpeed: 2, statDamage: 5, statHealth: 3,
    maxHp: 100, moveSpeed: 142,
    weapon: { name: "Gully Scope", dmg: 48, rate: 1.0, speed: 940, spread: 0.008, ammo: 6, reload: 1.9, range: 760, bulletSize: 4, bulletColor: "#ffe066", pierce: true },
  },
  {
    id: "auto", name: "Auto Rickshaw Rowdy", tagline: "Meter down, speed up!",
    emoji: "🛺", abilityName: "Rickshaw Rush",
    abilityDesc: "Hops in the auto — massive speed boost & rams enemies.",
    specialCd: 9,
    body: "#ffd400", body2: "#111827", skin: "#c98a5b", hair: "#111", 
    statSpeed: 5, statDamage: 3, statHealth: 4,
    maxHp: 115, moveSpeed: 172,
    weapon: { name: "Horn Blaster", dmg: 12, rate: 0.18, speed: 580, spread: 0.1, ammo: 20, reload: 1.3, range: 380, bulletSize: 3, bulletColor: "#ffe14d" },
  },
  {
    id: "sis", name: "Streamer Sis", tagline: "Thanks for the dono~",
    emoji: "💝", abilityName: "Donation Shield",
    abilityDesc: "Big self-heal + damage shield. Chat clips it instantly.",
    specialCd: 10,
    body: "#ef476f", body2: "#b02a50", skin: "#f2c19a", hair: "#5e3a8c",
    statSpeed: 3, statDamage: 2, statHealth: 5,
    maxHp: 135, moveSpeed: 164,
    weapon: { name: "Heart Beam", dmg: 10, rate: 0.15, speed: 640, spread: 0.07, ammo: 26, reload: 1.2, range: 410, bulletSize: 3, bulletColor: "#ff6b9d" },
  },
  {
    id: "gully", name: "Gully Gamer", tagline: "Gali ka OG.",
    emoji: "👊", abilityName: "Combo Dash",
    abilityDesc: "Dashes forward with a brutal close-range combo punch.",
    specialCd: 6,
    body: "#1d6fd1", body2: "#124a8f", skin: "#c98a5b", hair: "#0c0a09",
    statSpeed: 4, statDamage: 4, statHealth: 4,
    maxHp: 120, moveSpeed: 178,
    weapon: { name: "Knuckle Shot", dmg: 20, rate: 0.32, speed: 520, spread: 0.13, ammo: 10, reload: 1.4, range: 240, bulletSize: 4, bulletColor: "#6db4ff", pellets: 3 },
  },
  {
    id: "emoji", name: "Emoji Bomber", tagline: "💀💀💀 incoming.",
    emoji: "💣", abilityName: "Emoji Grenade",
    abilityDesc: "Lobs an exploding emoji — big boom, bigger disrespect.",
    specialCd: 7,
    body: "#fcbf49", body2: "#d68c00", skin: "#f0b184", hair: "#7a3b0a",
    statSpeed: 3, statDamage: 4, statHealth: 3,
    maxHp: 105, moveSpeed: 170,
    weapon: { name: "Reaction Repeater", dmg: 12, rate: 0.2, speed: 590, spread: 0.09, ammo: 18, reload: 1.4, range: 420, bulletSize: 4, bulletColor: "#ffdd57" },
  },
  {
    id: "rank", name: "Rank Pusher", tagline: "Bas ek aur match...",
    emoji: "📈", abilityName: "Grind Mode",
    abilityDesc: "Doubles fire-rate for 4s. Also gets faster as match goes on.",
    specialCd: 10,
    body: "#4c3ed9", body2: "#2c2394", skin: "#e0a370", hair: "#191428",
    statSpeed: 4, statDamage: 3, statHealth: 3,
    maxHp: 110, moveSpeed: 166,
    weapon: { name: "Grind Carbine", dmg: 12, rate: 0.16, speed: 640, spread: 0.07, ammo: 24, reload: 1.25, range: 450, bulletSize: 3, bulletColor: "#8d80ff" },
  },
  {
    id: "ghost", name: "Ghost Viewer", tagline: "Lurking since 2016.",
    emoji: "👁", abilityName: "Spectral Mode",
    abilityDesc: "Goes fully invisible & fast for 4s. Always semi-transparent.",
    specialCd: 9,
    body: "#8d99ae", body2: "#5b6478", skin: "#d8c3d8", hair: "#e5e5f0",
    statSpeed: 5, statDamage: 4, statHealth: 1,
    maxHp: 75, moveSpeed: 192,
    weapon: { name: "Lurker Dart", dmg: 17, rate: 0.22, speed: 680, spread: 0.04, ammo: 14, reload: 1.3, range: 480, bulletSize: 3, bulletColor: "#cdd6ff" },
  },
];

export const charById = (id: string): CharDef =>
  CHARACTERS.find((c) => c.id === id) ?? CHARACTERS[0];

export const BOT_NAMES = [
  "NoScopeNani", "LagKing420", "PaneerPapi", "MaccharMLG", "TharkiTurtle",
  "VadaPavVicky", "SasuMaaSlayer", "JugaadJockey", "BhindiBoss", "OP_Chintu",
  "HeadshotHema", "CringeLordC", "FullPowerPapa", "Dhokla_Dev",
];

export const KILL_MEMES = [
  "sent to lobby 💀", "got RATIO'd 📉", "ne uninstall kar diya 😂",
  "got full roasted 🔥", "EZ clap 👏", "bahut hard, bahut hard 💯",
  "mummy ne bula liya 🏃", "network issue (skill) 📶", "got chappal'd 🩴",
  "L + bye bye 👋", "OP bhai OP 🙌", "gaya kaam se 🪦",
];

export const DEATH_LINES = [
  "ARRE YAAR! 💀", "LAG THA BRO 📶", "REPORT KARO! 😤",
  "HACKER HAI! 🤬", "BAS 1 HP THA 😭", "TEAM KIDHAR HAI 🗣️",
];
