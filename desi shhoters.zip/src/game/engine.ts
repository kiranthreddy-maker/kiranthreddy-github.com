import { CHARACTERS, charById, BOT_NAMES, KILL_MEMES, DEATH_LINES } from "./characters";
import type { CharDef } from "./characters";
import { drawFighterSprite, drawDeadSprite } from "./sprites";
import { audio } from "./audio";

// ================= Types =================
export interface GameSettings { sfx: boolean; music: boolean; shake: boolean }
export interface ScoreRow { name: string; charId: string; kills: number; deaths: number; score: number; isPlayer: boolean }
export interface MatchResult { rows: ScoreRow[]; playerRank: number; playerScore: number; playerKills: number; mvpName: string }
export interface GameCallbacks { onGameOver: (r: MatchResult) => void; onPauseChange: (p: boolean) => void }

interface AI { wx: number; wy: number; repathT: number; targetId: number; retargetT: number; strafePhase: number; strafeDir: number; aimErr: number; stuckT: number; px: number; py: number }

interface Fighter {
  id: number; def: CharDef; name: string; isPlayer: boolean;
  x: number; y: number; kbx: number; kby: number;
  aim: number; flip: boolean; frame: number; moving: boolean;
  hp: number; maxHp: number; dead: boolean; deadT: number; respawnT: number;
  ammo: number; reloadT: number; fireT: number;
  spCd: number; invisT: number; stunT: number; speedT: number; shieldT: number;
  frenzyT: number; frenzyRate: number; autoT: number; dashT: number; bigShot: boolean; burnT: number;
  kills: number; deaths: number; score: number; streak: number; hitFlash: number; ramCd: number;
  ai: AI | null;
}

interface Bullet { x: number; y: number; vx: number; vy: number; dmg: number; owner: number; dist: number; range: number; size: number; color: string; pierce: boolean; splash: number; hit: Set<number> }
interface Grenade { x: number; y: number; vx: number; vy: number; t: number; fuse: number; owner: number; kind: "chai" | "emoji" }
interface Trap { x: number; y: number; kind: "banana" | "meme"; owner: number; life: number; memoji: string }
interface Pickup { x: number; y: number; kind: "chai" | "data" | "wifi"; bob: number }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string; kind: "rect" | "emoji" | "ring"; text?: string; grav: number }
interface FloatText { x: number; y: number; t: number; text: string; color: string; size: number }
interface Decoy { x: number; y: number; def: CharDef; t: number }

// ================= Constants =================
const TILE = 32, MW = 46, MH = 38;
const WORLD_W = MW * TILE, WORLD_H = MH * TILE;
const MATCH_TIME = 150, KILL_TARGET = 15, R = 11;
const PLAYER_HP_MULTIPLIER = 1.15;
const PLAYER_DAMAGE_MULTIPLIER = 1.1;

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const dist2 = (ax: number, ay: number, bx: number, by: number) => { const dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; };

function mulberry(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type CoverType = "crate" | "barrel" | "cart" | "auto" | "arcade" | "table" | "plant" | "ac" | "cooler" | "counter";
interface Cover { tx: number; ty: number; type: CoverType }

// ================= Map =================
class GameMap {
  wall = new Uint8Array(MW * MH); // 1 = building wall
  solid = new Uint8Array(MW * MH); // wall or cover
  floor = new Uint8Array(MW * MH); // 0 street 2 cafe 3 roof 4 tapri
  covers: Cover[] = [];
  spawns: [number, number][] = [];
  pickupSpots: [number, number][] = [];
  canvas: HTMLCanvasElement;
  mini: HTMLCanvasElement;

  constructor() {
    this.build();
    this.canvas = document.createElement("canvas");
    this.mini = document.createElement("canvas");
    this.render();
    this.renderMini();
  }

  idx(x: number, y: number) { return y * MW + x; }
  isWall(tx: number, ty: number) { return tx < 0 || ty < 0 || tx >= MW || ty >= MH || this.wall[this.idx(tx, ty)] === 1; }
  isSolid(tx: number, ty: number) { return tx < 0 || ty < 0 || tx >= MW || ty >= MH || this.solid[this.idx(tx, ty)] !== 0; }
  solidAt(px: number, py: number) { return this.isSolid(Math.floor(px / TILE), Math.floor(py / TILE)); }
  wallAt(px: number, py: number) { return this.isWall(Math.floor(px / TILE), Math.floor(py / TILE)); }

  private setWall(x: number, y: number) { if (x >= 0 && y >= 0 && x < MW && y < MH) { this.wall[this.idx(x, y)] = 1; this.solid[this.idx(x, y)] = 1; } }
  private setFloor(x: number, y: number, f: number) { if (x >= 0 && y >= 0 && x < MW && y < MH) this.floor[this.idx(x, y)] = f; }
  private addCover(tx: number, ty: number, type: CoverType) {
    if (this.solid[this.idx(tx, ty)]) return;
    this.covers.push({ tx, ty, type });
    this.solid[this.idx(tx, ty)] = 2;
  }

  private build() {
    // border
    for (let x = 0; x < MW; x++) { this.setWall(x, 0); this.setWall(x, MH - 1); }
    for (let y = 0; y < MH; y++) { this.setWall(0, y); this.setWall(MW - 1, y); }

    // ---- Rooftop terrace (top-left) ----
    for (let x = 2; x <= 15; x++) for (let y = 2; y <= 12; y++) this.setFloor(x, y, 3);
    for (let x = 2; x <= 15; x++) { if (x !== 8 && x !== 9) this.setWall(x, 12); }
    for (let y = 2; y <= 12; y++) { if (y !== 6 && y !== 7) this.setWall(15, y); }
    this.addCover(4, 4, "ac"); this.addCover(11, 4, "ac");
    this.addCover(7, 8, "cooler"); this.addCover(12, 9, "crate");
    this.addCover(3, 9, "plant");

    // ---- Chai tapri (top-right) ----
    for (let x = 31; x <= 43; x++) for (let y = 2; y <= 10; y++) this.setFloor(x, y, 4);
    for (let y = 2; y <= 10; y++) { if (y !== 5 && y !== 6) this.setWall(31, y); }
    for (let x = 31; x <= 43; x++) { if (x !== 36 && x !== 37) this.setWall(x, 10); }
    this.addCover(34, 3, "counter"); this.addCover(35, 3, "counter"); this.addCover(36, 3, "counter");
    this.addCover(40, 5, "table"); this.addCover(41, 8, "table"); this.addCover(34, 7, "table");
    this.addCover(39, 3, "barrel");

    // ---- Gaming café (bottom-right) ----
    for (let x = 29; x <= 43; x++) for (let y = 23; y <= 35; y++) this.setFloor(x, y, 2);
    for (let x = 29; x <= 43; x++) { if (x !== 34 && x !== 35 && x !== 40) this.setWall(x, 23); }
    for (let y = 23; y <= 35; y++) { if (y !== 29 && y !== 30) this.setWall(29, y); }
    this.addCover(32, 26, "arcade"); this.addCover(33, 26, "arcade");
    this.addCover(37, 26, "arcade"); this.addCover(38, 26, "arcade");
    this.addCover(32, 31, "arcade"); this.addCover(33, 31, "arcade");
    this.addCover(37, 31, "arcade"); this.addCover(38, 31, "arcade");
    this.addCover(41, 28, "table"); this.addCover(41, 33, "cooler");

    // ---- Gully streets: scattered cover ----
    const carts: [number, number, CoverType][] = [
      [20, 5, "cart"], [24, 9, "auto"], [7, 18, "cart"], [12, 22, "auto"],
      [20, 17, "crate"], [21, 17, "crate"], [20, 18, "barrel"],
      [27, 15, "cart"], [33, 15, "crate"], [34, 16, "barrel"],
      [5, 28, "auto"], [10, 30, "cart"], [16, 28, "crate"], [16, 29, "crate"],
      [22, 26, "barrel"], [23, 31, "cart"], [26, 20, "plant"], [14, 15, "plant"],
      [3, 22, "barrel"], [40, 14, "cart"], [43, 18, "crate"], [36, 19, "barrel"],
      [19, 34, "crate"], [26, 34, "auto"], [2, 34, "plant"], [28, 6, "crate"], [28, 7, "barrel"],
    ];
    for (const [x, y, t] of carts) this.addCover(x, y, t);

    // spawns (open street corners & rooms)
    const sp: [number, number][] = [
      [5, 15], [18, 3], [26, 12], [42, 12], [3, 25], [14, 33], [32, 20], [41, 31],
      [8, 6], [37, 6], [22, 22], [35, 33], [25, 28], [10, 26],
    ];
    for (const [x, y] of sp) if (!this.isSolid(x, y)) this.spawns.push([x * TILE + 16, y * TILE + 16]);

    const pu: [number, number][] = [
      [9, 9], [37, 5], [35, 29], [21, 20], [6, 21], [28, 27], [42, 16], [17, 31], [25, 4], [31, 13],
    ];
    for (const [x, y] of pu) if (!this.isSolid(x, y)) this.pickupSpots.push([x * TILE + 16, y * TILE + 16]);
  }

  private render() {
    const c = this.canvas;
    c.width = WORLD_W; c.height = WORLD_H;
    const g = c.getContext("2d")!;
    g.imageSmoothingEnabled = false;
    const rand = mulberry(1337);

    for (let ty = 0; ty < MH; ty++) {
      for (let tx = 0; tx < MW; tx++) {
        const f = this.floor[this.idx(tx, ty)];
        const X = tx * TILE, Y = ty * TILE;
        const n = rand();
        if (this.wall[this.idx(tx, ty)]) continue; // draw walls later
        if (f === 3) { // rooftop - terracotta
          g.fillStyle = n > 0.85 ? "#8a4a3c" : "#7d4136";
          g.fillRect(X, Y, TILE, TILE);
          g.fillStyle = "rgba(0,0,0,0.15)";
          g.fillRect(X, Y + TILE - 2, TILE, 2); g.fillRect(X + TILE - 2, Y, 2, TILE);
          if (n > 0.93) { g.fillStyle = "#6b3529"; g.fillRect(X + 8, Y + 8, 6, 6); }
        } else if (f === 2) { // cafe - dark neon floor
          g.fillStyle = (tx + ty) % 2 === 0 ? "#221838" : "#1d1430";
          g.fillRect(X, Y, TILE, TILE);
          if ((tx * 7 + ty * 3) % 9 === 0) { g.fillStyle = "rgba(36,224,255,0.25)"; g.fillRect(X + 13, Y + 13, 5, 5); }
        } else if (f === 4) { // tapri - wooden planks
          g.fillStyle = n > 0.8 ? "#93714c" : "#8a6a46";
          g.fillRect(X, Y, TILE, TILE);
          g.fillStyle = "rgba(0,0,0,0.12)";
          g.fillRect(X, Y + 15, TILE, 2);
        } else { // street asphalt
          g.fillStyle = n > 0.88 ? "#413a4d" : n > 0.4 ? "#3a3344" : "#373040";
          g.fillRect(X, Y, TILE, TILE);
          if (n > 0.965) { g.fillStyle = "#4a4258"; g.beginPath(); g.arc(X + 16, Y + 16, 7, 0, 7); g.fill(); g.fillStyle = "#322c3c"; g.beginPath(); g.arc(X + 16, Y + 16, 4, 0, 7); g.fill(); }
          else if (n < 0.03) { g.fillStyle = "#57436a"; g.fillRect(X + 6, Y + 10, 12, 3); } // trash
        }
      }
    }
    // road center lines
    g.fillStyle = "#c9b458";
    for (let ty = 1; ty < MH - 1; ty++) if (ty % 2 === 0 && this.floor[this.idx(23, ty)] === 0 && !this.solid[this.idx(23, ty)]) g.fillRect(23 * TILE - 2, ty * TILE + 6, 4, 18);
    for (let tx = 1; tx < MW - 1; tx++) if (tx % 2 === 0 && this.floor[this.idx(tx, 19)] === 0 && !this.solid[this.idx(tx, 19)]) g.fillRect(tx * TILE + 6, 19 * TILE - 2, 18, 4);

    // walls (2.5D)
    for (let ty = 0; ty < MH; ty++) {
      for (let tx = 0; tx < MW; tx++) {
        if (!this.wall[this.idx(tx, ty)]) continue;
        const X = tx * TILE, Y = ty * TILE;
        const inCafe = tx >= 29 && ty >= 23; const inTapri = tx >= 31 && ty <= 10; const inRoof = tx <= 15 && ty <= 12;
        g.fillStyle = inCafe ? "#2e2247" : inTapri ? "#6b4b31" : inRoof ? "#5c3a45" : "#4a3d59";
        g.fillRect(X, Y, TILE, TILE);
        g.fillStyle = "rgba(255,255,255,0.06)";
        g.fillRect(X, Y, TILE, 3);
        const openBelow = !this.isWall(tx, ty + 1);
        if (openBelow) {
          g.fillStyle = inCafe ? "#1c1430" : inTapri ? "#4a3322" : inRoof ? "#3f2730" : "#332a40";
          g.fillRect(X, Y + 12, TILE, TILE - 12);
          // brick pattern
          g.fillStyle = "rgba(0,0,0,0.18)";
          g.fillRect(X, Y + 19, TILE, 1); g.fillRect(X + (tx % 2 ? 8 : 20), Y + 13, 1, 6);
          // neon strip
          const neon = inCafe ? "#24e0ff" : inTapri ? "#ffb84d" : (tx + ty) % 5 === 0 ? "#ff3d8b" : null;
          if (neon) { g.fillStyle = neon; g.globalAlpha = 0.9; g.fillRect(X, Y + 11, TILE, 2); g.globalAlpha = 1; }
        }
      }
    }
    // signboards
    const sign = (x: number, y: number, text: string, bg: string, fg: string) => {
      const w = text.length * 7 + 10;
      g.fillStyle = "#170f22"; g.fillRect(x - 2, y - 2, w + 4, 16);
      g.fillStyle = bg; g.fillRect(x, y, w, 12);
      g.fillStyle = fg; g.font = "bold 9px monospace"; g.textBaseline = "middle";
      g.fillText(text, x + 5, y + 7);
    };
    sign(33 * TILE, 23 * TILE + 14, "CYBER ZONE ▶", "#12082a", "#24e0ff");
    sign(36 * TILE, 10 * TILE + 14, "CHAI ₹10", "#3d2410", "#ffd400");
    sign(4 * TILE, 12 * TILE + 14, "ROOFTOP GG", "#2a1020", "#ff3d8b");
    sign(19 * TILE, 0 * TILE + 14, "GULLY ARENA", "#101828", "#9ef01a");
    sign(9 * TILE, 37 * TILE - 18, "MOMO ☆ PAV", "#241028", "#ffb84d");
  }

  private renderMini() {
    const m = this.mini; m.width = MW * 3; m.height = MH * 3;
    const g = m.getContext("2d")!;
    g.fillStyle = "#161022"; g.fillRect(0, 0, m.width, m.height);
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      const f = this.floor[this.idx(tx, ty)];
      if (f === 2) g.fillStyle = "#2a1f4d"; else if (f === 3) g.fillStyle = "#4a2a24"; else if (f === 4) g.fillStyle = "#4d3a24"; else g.fillStyle = "#241d31";
      g.fillRect(tx * 3, ty * 3, 3, 3);
      if (this.wall[this.idx(tx, ty)]) { g.fillStyle = "#6b5a85"; g.fillRect(tx * 3, ty * 3, 3, 3); }
      else if (this.solid[this.idx(tx, ty)]) { g.fillStyle = "#54486b"; g.fillRect(tx * 3, ty * 3, 3, 3); }
    }
  }
}

// ================= Cover drawing =================
function drawCover(g: CanvasRenderingContext2D, cv: Cover, time: number) {
  const X = cv.tx * TILE, Y = cv.ty * TILE;
  g.save();
  g.translate(X, Y);
  // ground shadow
  g.fillStyle = "rgba(0,0,0,0.3)";
  g.fillRect(2, 22, 28, 8);
  switch (cv.type) {
    case "crate":
      g.fillStyle = "#8a5a2b"; g.fillRect(2, 2, 28, 26);
      g.fillStyle = "#a06c36"; g.fillRect(4, 4, 24, 10);
      g.fillStyle = "#6e4520"; g.fillRect(2, 24, 28, 4); g.fillRect(14, 2, 4, 26);
      break;
    case "barrel":
      g.fillStyle = "#31589e"; g.beginPath(); g.arc(16, 16, 12, 0, 7); g.fill();
      g.fillStyle = "#4b74c4"; g.beginPath(); g.arc(16, 13, 9, 0, 7); g.fill();
      g.fillStyle = "#22406e"; g.fillRect(5, 15, 22, 3);
      break;
    case "cart": // thela
      g.fillStyle = "#7a4f24"; g.fillRect(1, 6, 30, 16);
      g.fillStyle = "#93622e"; g.fillRect(3, 8, 26, 6);
      g.fillStyle = "#e07b39"; g.fillRect(5, 3, 6, 5); g.fillStyle = "#ffd400"; g.fillRect(13, 3, 6, 5); g.fillStyle = "#38b000"; g.fillRect(21, 3, 6, 5);
      g.fillStyle = "#241a10"; g.beginPath(); g.arc(8, 25, 5, 0, 7); g.fill(); g.beginPath(); g.arc(24, 25, 5, 0, 7); g.fill();
      g.fillStyle = "#57430b"; g.beginPath(); g.arc(8, 25, 2, 0, 7); g.fill(); g.beginPath(); g.arc(24, 25, 2, 0, 7); g.fill();
      break;
    case "auto":
      g.fillStyle = "#111827"; g.fillRect(2, 12, 28, 14);
      g.fillStyle = "#ffd400"; g.fillRect(2, 2, 28, 12);
      g.fillStyle = "#0b1220"; g.fillRect(6, 4, 20, 7);
      g.fillStyle = "#9adcff"; g.fillRect(8, 5, 16, 5);
      g.fillStyle = "#111"; g.beginPath(); g.arc(7, 27, 4, 0, 7); g.fill(); g.beginPath(); g.arc(25, 27, 4, 0, 7); g.fill();
      g.fillStyle = "#1f9e4c"; g.fillRect(2, 12, 28, 3);
      break;
    case "arcade": {
      g.fillStyle = "#241b3d"; g.fillRect(3, 0, 26, 28);
      g.fillStyle = "#12082a"; g.fillRect(6, 3, 20, 12);
      const hue = (Math.sin(time * 2 + cv.tx) + 1) / 2;
      g.fillStyle = hue > 0.5 ? "#24e0ff" : "#ff3d8b"; g.globalAlpha = 0.85;
      g.fillRect(8, 5, 16, 8); g.globalAlpha = 1;
      g.fillStyle = "#ff3d8b"; g.fillRect(9, 19, 5, 4); g.fillStyle = "#ffd400"; g.fillRect(18, 19, 5, 4);
      break;
    }
    case "table":
      g.fillStyle = "#8a6a46"; g.beginPath(); g.arc(16, 14, 12, 0, 7); g.fill();
      g.fillStyle = "#a5825a"; g.beginPath(); g.arc(16, 12, 9, 0, 7); g.fill();
      g.fillStyle = "#e6dccb"; g.fillRect(11, 8, 5, 4); g.fillStyle = "#d4a373"; g.fillRect(18, 11, 4, 4);
      break;
    case "plant":
      g.fillStyle = "#b0492f"; g.fillRect(9, 16, 14, 10);
      g.fillStyle = "#2c7a2c"; g.beginPath(); g.arc(16, 10, 9, 0, 7); g.fill();
      g.fillStyle = "#3f9e3f"; g.beginPath(); g.arc(12, 7, 5, 0, 7); g.fill(); g.beginPath(); g.arc(21, 8, 5, 0, 7); g.fill();
      break;
    case "ac":
      g.fillStyle = "#aeb6c4"; g.fillRect(2, 4, 28, 22);
      g.fillStyle = "#8b93a3"; g.fillRect(5, 8, 22, 3); g.fillRect(5, 14, 22, 3); g.fillRect(5, 20, 22, 3);
      g.fillStyle = "#6d7484"; g.fillRect(2, 4, 28, 3);
      break;
    case "cooler":
      g.fillStyle = "#c93c3c"; g.fillRect(4, 2, 24, 26);
      g.fillStyle = "#e8e4da"; g.fillRect(7, 6, 18, 8);
      g.fillStyle = "#8f2323"; g.fillRect(4, 24, 24, 4);
      g.fillStyle = "#fff"; g.font = "bold 7px monospace"; g.fillText("COLA", 8, 21);
      break;
    case "counter":
      g.fillStyle = "#5c3a1e"; g.fillRect(0, 4, 32, 22);
      g.fillStyle = "#7a4f28"; g.fillRect(0, 4, 32, 8);
      g.fillStyle = "#b9b3a8"; g.fillRect(6, 6, 8, 5); // kettle
      g.fillStyle = "#d4a373"; g.fillRect(20, 7, 4, 4); g.fillRect(26, 7, 4, 4);
      break;
  }
  g.restore();
}

// ================= Game =================
export class Game {
  private canvas: HTMLCanvasElement;
  private g: CanvasRenderingContext2D;
  private map = new GameMap();
  private fighters: Fighter[] = [];
  private bullets: Bullet[] = [];
  private grenades: Grenade[] = [];
  private traps: Trap[] = [];
  private pickups: Pickup[] = [];
  private particles: Particle[] = [];
  private floats: FloatText[] = [];
  private decoys: Decoy[] = [];
  private feed: { text: string; t: number }[] = [];
  private banner = { text: "", t: 0 };
  private camX = 0; private camY = 0; private shake = 0;
  private zoom = 1.5; private w = 0; private h = 0; private dpr = 1;
  private keys = new Set<string>();
  private mouse = { x: 0, y: 0, down: false, rdown: false };
  private pointerReady = false;
  private time = MATCH_TIME; private elapsed = 0; private hitstop = 0;
  private paused = false; private over = false; private destroyed = false;
  private raf = 0; private last = 0;
  private pickupT = 3; private hintT = 7; private hurtT = 0; private showBoard = false;
  private settings: GameSettings;
  private cb: GameCallbacks;
  private isTouch = false;
  private moveStick = { id: -1, bx: 0, by: 0, dx: 0, dy: 0 };
  private aimStick = { id: -1, bx: 0, by: 0, dx: 0, dy: 0 };
  private spBtn = { x: 0, y: 0, r: 34 };
  private cleanups: (() => void)[] = [];
  private idSeq = 0;

  constructor(canvas: HTMLCanvasElement, charId: string, settings: GameSettings, cb: GameCallbacks) {
    this.canvas = canvas;
    this.g = canvas.getContext("2d")!;
    this.settings = settings;
    this.cb = cb;
    audio.settings.sfx = settings.sfx;
    audio.settings.music = settings.music;
    this.isTouch = window.matchMedia("(pointer: coarse)").matches;
    this.resize();

    // player
    const player = this.makeFighter(charId, "YOU", true);
    this.fighters.push(player);
    // bots — unique characters
    const pool = CHARACTERS.filter((c) => c.id !== charId).sort(() => Math.random() - 0.5);
    const names = [...BOT_NAMES].sort(() => Math.random() - 0.5);
    for (let i = 0; i < 7; i++) this.fighters.push(this.makeFighter(pool[i].id, names[i], false));
    this.placeSpawns();

    // initial pickups
    for (let i = 0; i < 4; i++) this.spawnPickup();

    this.bindInput();
    audio.unlock();
    if (settings.music) audio.startMusic();
    audio.sfx("start");
    this.setBanner("FIGHT! 🔥", 1.4);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  // ---------- setup ----------
  private makeFighter(charId: string, name: string, isPlayer: boolean): Fighter {
    const def = charById(charId);
    const maxHp = Math.round(def.maxHp * (isPlayer ? PLAYER_HP_MULTIPLIER : 1));
    return {
      id: this.idSeq++, def, name, isPlayer,
      x: 0, y: 0, kbx: 0, kby: 0, aim: 0, flip: false, frame: 0, moving: false,
      hp: maxHp, maxHp, dead: false, deadT: 0, respawnT: 0,
      ammo: def.weapon.ammo, reloadT: 0, fireT: 0, spCd: 0,
      invisT: 0, stunT: 0, speedT: 0, shieldT: 0, frenzyT: 0, frenzyRate: 1,
      autoT: 0, dashT: 0, bigShot: false, burnT: 0,
      kills: 0, deaths: 0, score: 0, streak: 0, hitFlash: 0, ramCd: 0,
      ai: isPlayer ? null : { wx: 0, wy: 0, repathT: 0, targetId: -1, retargetT: rnd(0, 0.4), strafePhase: rnd(0, 6), strafeDir: Math.random() < 0.5 ? -1 : 1, aimErr: rnd(0.11, 0.3), stuckT: 0, px: 0, py: 0 },
    };
  }

  private placeSpawns() {
    const spots = [...this.map.spawns].sort(() => Math.random() - 0.5);
    this.fighters.forEach((f, i) => {
      const s = spots[i % spots.length];
      f.x = s[0]; f.y = s[1];
    });
    // guarantee an enemy near the player for instant action
    const p = this.fighters[0];
    const near = this.fighters[1];
    const ns = this.map.spawns.filter((s) => { const d = dist2(s[0], s[1], p.x, p.y); return d > 200 * 200 && d < 480 * 480; });
    if (ns.length) { const s = ns[0]; near.x = s[0]; near.y = s[1]; }
  }

  private respawnPos(f: Fighter) {
    let best: [number, number] = this.map.spawns[0]; let bestD = -1;
    for (const s of this.map.spawns) {
      let minD = Infinity;
      for (const o of this.fighters) if (o !== f && !o.dead) minD = Math.min(minD, dist2(s[0], s[1], o.x, o.y));
      if (minD > bestD) { bestD = minD; best = s; }
    }
    f.x = best[0] + rnd(-8, 8); f.y = best[1] + rnd(-8, 8);
  }

  // ---------- input ----------
  private bindInput() {
    const kd = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const k = e.key.toLowerCase();
      if (k === "tab") { e.preventDefault(); this.showBoard = true; return; }
      if (k === "escape") { e.preventDefault(); this.togglePause(); return; }
      this.keys.add(k);
      if (k === "r") this.startReload(this.fighters[0]);
      audio.unlock();
    };
    const ku = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "tab") { this.showBoard = false; return; }
      this.keys.delete(k);
    };
    const mm = (e: MouseEvent) => {
      const r = this.canvas.getBoundingClientRect();
      this.mouse.x = e.clientX - r.left; this.mouse.y = e.clientY - r.top;
      this.pointerReady = true;
    };
    const md = (e: MouseEvent) => {
      audio.unlock();
      if (e.button === 0) this.mouse.down = true;
      if (e.button === 2) { this.mouse.rdown = true; this.trySpecial(this.fighters[0]); }
    };
    const mu = (e: MouseEvent) => {
      if (e.button === 0) this.mouse.down = false;
      if (e.button === 2) this.mouse.rdown = false;
    };
    const cm = (e: Event) => e.preventDefault();
    const rs = () => this.resize();

    const ts = (e: TouchEvent) => {
      e.preventDefault(); audio.unlock();
      const r = this.canvas.getBoundingClientRect();
      for (const t of Array.from(e.changedTouches)) {
        const x = t.clientX - r.left, y = t.clientY - r.top;
        // special button?
        if (Math.hypot(x - this.spBtn.x, y - this.spBtn.y) < this.spBtn.r + 8) { this.trySpecial(this.fighters[0]); continue; }
        if (x < this.w / 2 && this.moveStick.id === -1) { this.moveStick = { id: t.identifier, bx: x, by: y, dx: 0, dy: 0 }; }
        else if (this.aimStick.id === -1) { this.aimStick = { id: t.identifier, bx: x, by: y, dx: 0, dy: 0 }; }
      }
    };
    const tm = (e: TouchEvent) => {
      e.preventDefault();
      const r = this.canvas.getBoundingClientRect();
      for (const t of Array.from(e.changedTouches)) {
        const x = t.clientX - r.left, y = t.clientY - r.top;
        for (const st of [this.moveStick, this.aimStick]) {
          if (st.id === t.identifier) {
            st.dx = clamp(x - st.bx, -52, 52); st.dy = clamp(y - st.by, -52, 52);
          }
        }
      }
    };
    const te = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (this.moveStick.id === t.identifier) this.moveStick = { id: -1, bx: 0, by: 0, dx: 0, dy: 0 };
        if (this.aimStick.id === t.identifier) this.aimStick = { id: -1, bx: 0, by: 0, dx: 0, dy: 0 };
      }
    };

    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("mousemove", mm);
    this.canvas.addEventListener("mousedown", md);
    window.addEventListener("mouseup", mu);
    this.canvas.addEventListener("contextmenu", cm);
    window.addEventListener("resize", rs);
    this.canvas.addEventListener("touchstart", ts, { passive: false });
    this.canvas.addEventListener("touchmove", tm, { passive: false });
    this.canvas.addEventListener("touchend", te);
    this.canvas.addEventListener("touchcancel", te);
    this.cleanups.push(() => {
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("mousemove", mm);
      this.canvas.removeEventListener("mousedown", md);
      window.removeEventListener("mouseup", mu);
      this.canvas.removeEventListener("contextmenu", cm);
      window.removeEventListener("resize", rs);
      this.canvas.removeEventListener("touchstart", ts);
      this.canvas.removeEventListener("touchmove", tm);
      this.canvas.removeEventListener("touchend", te);
      this.canvas.removeEventListener("touchcancel", te);
    });
  }

  private resize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    this.w = parent.clientWidth; this.h = parent.clientHeight;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(this.w * this.dpr);
    this.canvas.height = Math.floor(this.h * this.dpr);
    this.canvas.style.width = this.w + "px";
    this.canvas.style.height = this.h + "px";
    this.zoom = clamp(Math.min(this.w, this.h) / 430, 1.05, 1.8);
    this.spBtn.x = this.w - 64; this.spBtn.y = this.h - 176;
  }

  togglePause() {
    if (this.over) return;
    this.paused = !this.paused;
    this.cb.onPauseChange(this.paused);
    audio.sfx("click");
  }
  setPaused(p: boolean) { this.paused = p; }
  updateSettings(s: GameSettings) {
    this.settings = s;
    audio.settings.sfx = s.sfx; audio.settings.music = s.music;
    if (s.music) audio.startMusic(); else audio.stopMusic();
  }
  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    audio.stopMusic();
    for (const c of this.cleanups) c();
  }

  // ---------- helpers ----------
  private setBanner(text: string, t = 1.6) { this.banner = { text, t }; }
  private addShake(amt: number) { if (this.settings.shake) this.shake = Math.min(14, this.shake + amt); }
  private float(x: number, y: number, text: string, color: string, size = 12) {
    this.floats.push({ x, y, t: 0, text, color, size });
  }
  private burst(x: number, y: number, color: string, n = 10, speed = 160) {
    for (let i = 0; i < n; i++) {
      const a = rnd(0, Math.PI * 2), s = rnd(speed * 0.3, speed);
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0, max: rnd(0.3, 0.65), size: rnd(2, 5), color, kind: "rect", grav: 220 });
    }
  }
  private emojiBurst(x: number, y: number, chars: string[], n = 6) {
    for (let i = 0; i < n; i++) {
      const a = rnd(-Math.PI, 0), s = rnd(60, 200);
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 60, life: 0, max: rnd(0.6, 1.1), size: rnd(10, 16), color: "#fff", kind: "emoji", text: chars[Math.floor(Math.random() * chars.length)], grav: 300 });
    }
  }
  private ring(x: number, y: number, color: string, size: number) {
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0, max: 0.4, size, color, kind: "ring", grav: 0 });
  }
  private los(ax: number, ay: number, bx: number, by: number) {
    const d = Math.hypot(bx - ax, by - ay);
    const steps = Math.ceil(d / 12);
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      if (this.map.wallAt(ax + (bx - ax) * t, ay + (by - ay) * t)) return false;
    }
    return true;
  }

  private isAimingAtOpponent(f: Fighter) {
    const dirX = Math.cos(f.aim), dirY = Math.sin(f.aim);
    const muzzleX = f.x + dirX * 14;
    const muzzleY = f.y - 4 + dirY * 14;
    const maxDistance = f.def.weapon.range;

    for (const opponent of this.fighters) {
      if (opponent === f || opponent.dead) continue;
      const dx = opponent.x - muzzleX;
      const dy = opponent.y - 6 - muzzleY;
      const along = dx * dirX + dy * dirY;
      if (along <= 0 || along > maxDistance) continue;

      // Fire only when the opponent is close to the shot line and not behind cover.
      const across = Math.abs(dx * dirY - dy * dirX);
      if (across > R + f.def.weapon.bulletSize + 5) continue;
      const steps = Math.ceil(along / 10);
      let blocked = false;
      for (let i = 1; i < steps; i++) {
        const t = i / steps;
        if (this.map.solidAt(muzzleX + dx * t, muzzleY + dy * t)) {
          blocked = true;
          break;
        }
      }
      if (!blocked) return true;
    }
    return false;
  }

  private spawnPickup() {
    if (this.pickups.length >= 6) return;
    const spots = this.map.pickupSpots.filter((s) => !this.pickups.some((p) => dist2(p.x, p.y, s[0], s[1]) < 100));
    if (!spots.length) return;
    const s = spots[Math.floor(Math.random() * spots.length)];
    const kinds: Pickup["kind"][] = ["chai", "chai", "chai", "data", "data", "wifi"];
    this.pickups.push({ x: s[0], y: s[1], kind: kinds[Math.floor(Math.random() * kinds.length)], bob: rnd(0, 6) });
  }

  // ---------- combat ----------
  private startReload(f: Fighter) {
    if (f.dead || f.reloadT > 0 || f.ammo >= f.def.weapon.ammo) return;
    f.reloadT = f.def.weapon.reload;
    if (f.isPlayer) audio.sfx("reload");
  }

  private fireWeapon(f: Fighter, accMult = 1) {
    const w = f.def.weapon;
    if (f.fireT > 0 || f.reloadT > 0 || f.dead || f.stunT > 0) return;
    if (f.ammo <= 0) { this.startReload(f); if (f.isPlayer) audio.sfx("empty"); return; }
    const rate = w.rate / (f.frenzyT > 0 ? f.frenzyRate : 1);
    f.fireT = rate * (f.isPlayer ? 1 : 1.12);
    f.ammo--;
    f.invisT = Math.min(f.invisT, 0.1); // shooting breaks stealth
    const pellets = w.pellets ?? 1;
    const dmgMul = (f.isPlayer ? PLAYER_DAMAGE_MULTIPLIER : 1) * (f.frenzyT > 0 && f.def.id === "duo" ? 1.4 : 1);
    for (let i = 0; i < pellets; i++) {
      const off = pellets > 1 ? (i - (pellets - 1) / 2) * 0.09 : 0;
      const a = f.aim + off + rnd(-w.spread, w.spread) * accMult;
      const big = f.bigShot;
      this.bullets.push({
        x: f.x + Math.cos(f.aim) * 14, y: f.y - 4 + Math.sin(f.aim) * 14,
        vx: Math.cos(a) * w.speed * (big ? 1.2 : 1), vy: Math.sin(a) * w.speed * (big ? 1.2 : 1),
        dmg: (big ? 90 : w.dmg) * dmgMul, owner: f.id, dist: 0, range: big ? 900 : w.range,
        size: big ? 7 : w.bulletSize, color: big ? "#ff3d3d" : w.bulletColor,
        pierce: big || !!w.pierce, splash: w.splash ?? 0, hit: new Set(),
      });
    }
    if (f.bigShot) { f.bigShot = false; audio.sfx("sniper"); this.addShake(5); }
    else if (f.isPlayer || dist2(f.x, f.y, this.fighters[0].x, this.fighters[0].y) < 500 * 500) {
      audio.sfx(f.def.id === "sniper" ? "sniper" : f.def.weapon.dmg >= 15 ? "shoot2" : "shoot");
    }
    // muzzle flash
    this.particles.push({ x: f.x + Math.cos(f.aim) * 18, y: f.y - 4 + Math.sin(f.aim) * 18, vx: 0, vy: 0, life: 0, max: 0.06, size: 6, color: "#fff6c9", kind: "rect", grav: 0 });
    if (f.isPlayer) this.addShake(0.7);
    if (f.ammo <= 0) this.startReload(f);
  }

  private damage(target: Fighter, amount: number, from: Fighter | null, kb = 0, ang = 0) {
    if (target.dead) return;
    let dmg = amount;
    if (target.shieldT > 0) dmg *= 0.4;
    if (target.isPlayer && this.keys.has("control")) dmg *= 0.75;
    if (target.isPlayer && from && !from.isPlayer) dmg *= 0.65; // bot mercy
    dmg = Math.max(1, Math.round(dmg));
    target.hp -= dmg;
    target.hitFlash = 0.12;
    target.invisT = Math.min(target.invisT, 0.05);
    if (kb > 0) { target.kbx += Math.cos(ang) * kb; target.kby += Math.sin(ang) * kb; }
    this.float(target.x + rnd(-6, 6), target.y - 26, `${dmg}`, target.isPlayer ? "#ff5d5d" : "#ffe066", target.isPlayer ? 13 : 11);
    this.burst(target.x, target.y - 8, "#ff6b6b", 4, 120);
    if (target.isPlayer) { this.hurtT = 0.25; this.addShake(3); audio.sfx("hurt"); }
    else if (from?.isPlayer) audio.sfx("hit");
    if (target.hp <= 0) this.kill(from, target);
  }

  private kill(killer: Fighter | null, victim: Fighter) {
    victim.dead = true; victim.deadT = 0; victim.respawnT = 2.3;
    victim.deaths++; victim.streak = 0; victim.hp = 0;
    victim.invisT = 0; victim.stunT = 0; victim.autoT = 0;
    this.emojiBurst(victim.x, victim.y - 10, ["💀", "😂", "🔥", "🩴"], 7);
    this.burst(victim.x, victim.y - 8, victim.def.body, 16, 220);
    this.ring(victim.x, victim.y - 8, "#ffd400", 40);
    this.hitstop = 0.085;
    audio.sfx(victim.isPlayer ? "death" : "kill");
    const meme = KILL_MEMES[Math.floor(Math.random() * KILL_MEMES.length)];
    if (killer && killer !== victim) {
      killer.kills++; killer.streak++;
      killer.score += 100 + Math.min(killer.streak - 1, 4) * 25;
      this.feed.unshift({ text: `${killer.name} ⚔ ${victim.name} — ${meme}`, t: 0 });
      if (killer.isPlayer) {
        this.addShake(4);
        this.setBanner(killer.streak >= 3 ? `${killer.streak} STREAK! OP BHAI OP 🙌` : `+${100 + Math.min(killer.streak - 1, 4) * 25} • ${meme}`, 1.5);
      } else if (victim.isPlayer) {
        this.setBanner(DEATH_LINES[Math.floor(Math.random() * DEATH_LINES.length)], 1.8);
        this.addShake(6);
      }
    } else {
      this.feed.unshift({ text: `${victim.name} self-destructed 🤡`, t: 0 });
    }
    if (this.feed.length > 5) this.feed.pop();
    if (Math.random() < 0.35) this.pickups.push({ x: victim.x, y: victim.y, kind: Math.random() < 0.5 ? "chai" : "data", bob: 0 });
    if (killer && killer.kills >= KILL_TARGET) this.endMatch();
  }

  private explode(x: number, y: number, radius: number, dmg: number, ownerId: number, color: string, emojis: string[]) {
    this.ring(x, y, color, radius);
    this.burst(x, y, color, 18, 260);
    this.emojiBurst(x, y, emojis, 5);
    audio.sfx("explode");
    const owner = this.fighters.find((f) => f.id === ownerId) ?? null;
    for (const f of this.fighters) {
      if (f.dead || f.id === ownerId) continue;
      const d = Math.hypot(f.x - x, f.y - y);
      if (d < radius) {
        const fall = 1 - (d / radius) * 0.6;
        this.damage(f, dmg * fall, owner, 220, Math.atan2(f.y - y, f.x - x));
      }
    }
    const p = this.fighters[0];
    if (dist2(x, y, p.x, p.y) < 400 * 400) this.addShake(5);
  }

  // ---------- specials ----------
  private trySpecial(f: Fighter) {
    if (f.dead || f.spCd > 0 || f.stunT > 0 || this.paused || this.over) return;
    f.spCd = f.def.specialCd;
    const near = this.fighters[0];
    const playSfx = f.isPlayer || dist2(f.x, f.y, near.x, near.y) < 450 * 450;
    switch (f.def.id) {
      case "rager": {
        this.ring(f.x, f.y, "#ff5d4d", 95);
        this.emojiBurst(f.x, f.y - 10, ["🎮", "💢"], 4);
        if (playSfx) audio.sfx("explode");
        this.addShake(f.isPlayer ? 6 : 3);
        for (const o of this.fighters) {
          if (o === f || o.dead) continue;
          const d = Math.hypot(o.x - f.x, o.y - f.y);
          if (d < 100) this.damage(o, 45, f, 320, Math.atan2(o.y - f.y, o.x - f.x));
        }
        this.float(f.x, f.y - 40, "CONTROLLER SMASH!", "#ff5d4d", 12);
        break;
      }
      case "chaos":
        this.traps.push({ x: f.x + Math.cos(f.aim) * 26, y: f.y + Math.sin(f.aim) * 26, kind: "banana", owner: f.id, life: 14, memoji: "🍌" });
        if (playSfx) audio.sfx("click");
        break;
      case "duo":
        f.frenzyT = 2.6; f.frenzyRate = 2.4;
        this.float(f.x, f.y - 40, "TWIN VOLLEY!", "#4dffe3", 12);
        if (playSfx) audio.sfx("special");
        break;
      case "roast": {
        this.ring(f.x, f.y, "#c77dff", 150);
        this.ring(f.x, f.y, "#c77dff", 80);
        if (playSfx) audio.sfx("stun");
        for (const o of this.fighters) {
          if (o === f || o.dead) continue;
          if (Math.hypot(o.x - f.x, o.y - f.y) < 160) {
            o.stunT = Math.max(o.stunT, 1.5);
            this.damage(o, 10, f);
            this.float(o.x, o.y - 34, "ROASTED 🔥", "#c77dff", 10);
          }
        }
        break;
      }
      case "glitch": {
        this.burst(f.x, f.y - 8, "#f72585", 12, 200);
        let tx = f.x, ty = f.y;
        for (let d = 10; d <= 150; d += 10) {
          const nx = f.x + Math.cos(f.aim) * d, ny = f.y + Math.sin(f.aim) * d;
          if (this.map.solidAt(nx, ny)) break;
          tx = nx; ty = ny;
        }
        f.x = tx; f.y = ty;
        this.burst(f.x, f.y - 8, "#24e0ff", 12, 200);
        this.ring(f.x, f.y, "#24e0ff", 34);
        if (playSfx) audio.sfx("teleport");
        break;
      }
      case "chai":
        this.grenades.push({ x: f.x, y: f.y - 6, vx: Math.cos(f.aim) * 300, vy: Math.sin(f.aim) * 300, t: 0, fuse: 0.75, owner: f.id, kind: "chai" });
        if (playSfx) audio.sfx("special");
        break;
      case "meme":
        this.traps.push({ x: f.x + Math.cos(f.aim) * 26, y: f.y + Math.sin(f.aim) * 26, kind: "meme", owner: f.id, life: 16, memoji: ["🐸", "😹", "🗿", "💀"][Math.floor(Math.random() * 4)] });
        if (playSfx) audio.sfx("click");
        break;
      case "prank":
        f.invisT = 3;
        this.decoys.push({ x: f.x, y: f.y, def: f.def, t: 0 });
        this.float(f.x, f.y - 40, "JUST A PRANK BRO 👻", "#ff9ecb", 11);
        if (playSfx) audio.sfx("teleport");
        break;
      case "sniper":
        f.bigShot = true;
        this.float(f.x, f.y - 40, "DHAMAKA LOADED 🎯", "#ffe066", 11);
        if (playSfx) audio.sfx("special");
        break;
      case "auto":
        f.autoT = 3; f.speedT = Math.max(f.speedT, 3);
        this.float(f.x, f.y - 40, "METER DOWN! 🛺", "#ffd400", 12);
        this.emojiBurst(f.x, f.y, ["🛺", "💨"], 3);
        if (playSfx) audio.sfx("special");
        break;
      case "sis": {
        f.shieldT = 2.5;
        const heal = Math.min(55, f.maxHp - f.hp);
        f.hp += heal;
        this.float(f.x, f.y - 40, `+${Math.round(heal)} DONO 💝`, "#7dff9b", 12);
        this.ring(f.x, f.y, "#7dff9b", 50);
        if (playSfx) audio.sfx("heal");
        break;
      }
      case "gully": {
        f.dashT = 0.2;
        f.kbx += Math.cos(f.aim) * 620; f.kby += Math.sin(f.aim) * 620;
        if (playSfx) audio.sfx("special");
        for (const o of this.fighters) {
          if (o === f || o.dead) continue;
          const d = Math.hypot(o.x - f.x, o.y - f.y);
          const angTo = Math.atan2(o.y - f.y, o.x - f.x);
          let diff = Math.abs(angTo - f.aim); if (diff > Math.PI) diff = Math.PI * 2 - diff;
          if (d < 120 && diff < 0.7) this.damage(o, 34, f, 300, angTo);
        }
        this.float(f.x, f.y - 40, "COMBO DASH 👊", "#6db4ff", 12);
        break;
      }
      case "emoji":
        this.grenades.push({ x: f.x, y: f.y - 6, vx: Math.cos(f.aim) * 340, vy: Math.sin(f.aim) * 340, t: 0, fuse: 0.8, owner: f.id, kind: "emoji" });
        if (playSfx) audio.sfx("special");
        break;
      case "rank":
        f.frenzyT = 4; f.frenzyRate = 2;
        this.float(f.x, f.y - 40, "GRIND MODE 📈", "#8d80ff", 12);
        if (playSfx) audio.sfx("special");
        break;
      case "ghost":
        f.invisT = 4; f.speedT = Math.max(f.speedT, 4);
        this.float(f.x, f.y - 40, "SPECTRAL 👁", "#cdd6ff", 12);
        if (playSfx) audio.sfx("teleport");
        break;
    }
  }

  // ---------- update ----------
  private moveFighter(f: Fighter, dx: number, dy: number, dt: number) {
    const nx = f.x + dx * dt, ny = f.y + dy * dt;
    if (!this.collides(nx, f.y)) f.x = nx;
    if (!this.collides(f.x, ny)) f.y = ny;
    f.x = clamp(f.x, TILE + R, WORLD_W - TILE - R);
    f.y = clamp(f.y, TILE + R, WORLD_H - TILE - R);
  }
  private collides(x: number, y: number) {
    return this.map.solidAt(x - R, y - R * 0.6) || this.map.solidAt(x + R, y - R * 0.6) ||
      this.map.solidAt(x - R, y + R * 0.6) || this.map.solidAt(x + R, y + R * 0.6);
  }

  private updatePlayer(f: Fighter, dt: number) {
    if (f.dead) return;
    let mx = 0, my = 0;
    if (this.keys.has("w")) my -= 1;
    if (this.keys.has("s")) my += 1;
    if (this.keys.has("a")) mx -= 1;
    if (this.keys.has("d")) mx += 1;
    // touch stick
    if (this.moveStick.id !== -1) {
      const m = Math.hypot(this.moveStick.dx, this.moveStick.dy);
      if (m > 8) { mx = this.moveStick.dx / 52; my = this.moveStick.dy / 52; }
    }
    const mag = Math.hypot(mx, my);
    f.moving = mag > 0.05 && f.stunT <= 0;
    const sprint = this.keys.has("shift") || (this.moveStick.id !== -1 && mag > 0.92);
    const crouch = this.keys.has("control");
    let spd = f.def.moveSpeed;
    if (f.def.id === "rank") spd *= 1 + Math.min(0.35, (this.elapsed / 200) * 0.35);
    if (sprint) spd *= 1.32;
    if (crouch) spd *= 0.55;
    if (f.speedT > 0) spd *= f.autoT > 0 ? 1.85 : 1.45;
    if (f.stunT > 0) spd = 0;
    if (mag > 0.05) {
      const n = mag > 1 ? mag : 1;
      this.moveFighter(f, (mx / n) * spd, (my / n) * spd, dt);
      f.frame = (f.frame + dt * (spd / 42)) % 1;
    }
    // aim
    if (this.aimStick.id !== -1 && Math.hypot(this.aimStick.dx, this.aimStick.dy) > 10) {
      f.aim = Math.atan2(this.aimStick.dy, this.aimStick.dx);
      if (Math.hypot(this.aimStick.dx, this.aimStick.dy) > 22) this.fireWeapon(f);
    } else if (!this.isTouch) {
      const wx = this.camX + (this.mouse.x - this.w / 2) / this.zoom;
      const wy = this.camY + (this.mouse.y - this.h / 2) / this.zoom;
      f.aim = Math.atan2(wy - (f.y - 8), wx - f.x);
    }
    f.flip = Math.cos(f.aim) < 0;
    if (this.mouse.down || (!this.isTouch && this.pointerReady && this.isAimingAtOpponent(f))) {
      this.fireWeapon(f);
    }
    // pickups: auto + E
    const pr = this.keys.has("e") ? 46 : 24;
    this.collectPickups(f, pr);
  }

  private collectPickups(f: Fighter, radius: number) {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      if (dist2(p.x, p.y, f.x, f.y) < radius * radius) {
        this.pickups.splice(i, 1);
        if (p.kind === "chai") {
          const heal = Math.min(45, f.maxHp - f.hp);
          f.hp += heal;
          this.float(f.x, f.y - 34, `+${Math.round(heal)} ☕`, "#7dff9b", 12);
          if (f.isPlayer) audio.sfx("heal");
        } else if (p.kind === "data") {
          f.ammo = f.def.weapon.ammo; f.reloadT = 0;
          this.float(f.x, f.y - 34, "AMMO FULL 📦", "#6db4ff", 11);
          if (f.isPlayer) audio.sfx("pickup");
        } else {
          f.speedT = Math.max(f.speedT, 4);
          this.float(f.x, f.y - 34, "SPEED 📶", "#ffd400", 11);
          if (f.isPlayer) audio.sfx("pickup");
        }
        this.ring(f.x, f.y, "#fff", 22);
      }
    }
  }

  private updateBot(f: Fighter, dt: number) {
    if (f.dead || !f.ai) return;
    const ai = f.ai;
    ai.retargetT -= dt;
    if (ai.retargetT <= 0) {
      ai.retargetT = 0.35;
      let best = -1, bestD = Infinity;
      for (const o of this.fighters) {
        if (o === f || o.dead) continue;
        let detect = 380;
        if (o.invisT > 0.2) detect = 60;
        else if (o.def.id === "ghost") detect = 220;
        if (o.isPlayer && this.keys.has("control")) detect *= 0.7;
        const d = Math.hypot(o.x - f.x, o.y - f.y);
        if (d < detect && d < bestD && this.los(f.x, f.y, o.x, o.y)) { best = o.id; bestD = d; }
      }
      ai.targetId = best;
      // hurt? seek chai
      if (f.hp < f.maxHp * 0.45) {
        let bp: Pickup | null = null, bd = 340 * 340;
        for (const p of this.pickups) if (p.kind === "chai") { const d = dist2(p.x, p.y, f.x, f.y); if (d < bd) { bd = d; bp = p; } }
        if (bp) { ai.wx = bp.x; ai.wy = bp.y; ai.repathT = 2; }
      }
    }
    const target = this.fighters.find((o) => o.id === ai.targetId && !o.dead);
    let mx = 0, my = 0;
    if (target) {
      const d = Math.hypot(target.x - f.x, target.y - f.y);
      const trueAim = Math.atan2(target.y - 8 - (f.y - 8), target.x - f.x);
      const err = ai.aimErr * Math.sin(this.elapsed * 3 + ai.strafePhase) * (target.isPlayer && this.keys.has("control") ? 2 : 1);
      const desired = trueAim + err;
      let da = desired - f.aim;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      f.aim += da * Math.min(1, dt * 5.5);
      const pref = f.def.weapon.range * 0.5;
      const toward = d > pref + 30 ? 1 : d < pref - 40 ? -1 : 0;
      ai.strafePhase += dt;
      if (Math.sin(ai.strafePhase * 1.7) > 0.95) ai.strafeDir *= -1;
      const perp = trueAim + Math.PI / 2;
      mx = Math.cos(trueAim) * toward + Math.cos(perp) * ai.strafeDir * 0.8;
      my = Math.sin(trueAim) * toward + Math.sin(perp) * ai.strafeDir * 0.8;
      if (Math.abs(da) < 0.35 && d < f.def.weapon.range * 0.95 && this.los(f.x, f.y, target.x, target.y)) {
        this.fireWeapon(f, 2.2);
      }
      if (f.spCd <= 0 && Math.random() < dt * 0.3) {
        const id = f.def.id;
        const wantClose = id === "rager" || id === "gully" || id === "roast";
        const ok = wantClose ? d < 140 : id === "sis" ? f.hp < f.maxHp * 0.6 : id === "glitch" ? f.hp < f.maxHp * 0.5 || d > 200 : true;
        if (ok) this.trySpecial(f);
      }
    } else {
      ai.repathT -= dt;
      const dw = Math.hypot(ai.wx - f.x, ai.wy - f.y);
      if (ai.repathT <= 0 || dw < 30) {
        ai.repathT = rnd(2, 4);
        for (let tries = 0; tries < 12; tries++) {
          const tx = Math.floor(rnd(2, MW - 2)), ty = Math.floor(rnd(2, MH - 2));
          if (!this.map.isSolid(tx, ty)) { ai.wx = tx * TILE + 16; ai.wy = ty * TILE + 16; break; }
        }
      }
      const a = Math.atan2(ai.wy - f.y, ai.wx - f.x);
      mx = Math.cos(a); my = Math.sin(a);
      let da = a - f.aim;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      f.aim += da * Math.min(1, dt * 4);
    }
    // stuck detection
    ai.stuckT += dt;
    if (ai.stuckT > 0.5) {
      if (dist2(f.x, f.y, ai.px, ai.py) < 16) { ai.repathT = 0; ai.strafeDir *= -1; }
      ai.px = f.x; ai.py = f.y; ai.stuckT = 0;
    }
    const mag = Math.hypot(mx, my);
    f.moving = mag > 0.05 && f.stunT <= 0;
    if (mag > 0.05 && f.stunT <= 0) {
      let spd = f.def.moveSpeed * 0.92;
      if (f.def.id === "rank") spd *= 1 + Math.min(0.35, (this.elapsed / 200) * 0.35);
      if (f.speedT > 0) spd *= f.autoT > 0 ? 1.85 : 1.45;
      this.moveFighter(f, (mx / mag) * spd, (my / mag) * spd, dt);
      f.frame = (f.frame + dt * 4) % 1;
    }
    f.flip = Math.cos(f.aim) < 0;
    this.collectPickups(f, 20);
    if (f.ammo <= 0 && f.reloadT <= 0) this.startReload(f);
  }

  private updateFighterCommon(f: Fighter, dt: number) {
    f.fireT -= dt; f.spCd = Math.max(0, f.spCd - dt);
    f.hitFlash = Math.max(0, f.hitFlash - dt);
    f.invisT = Math.max(0, f.invisT - dt);
    f.stunT = Math.max(0, f.stunT - dt);
    f.speedT = Math.max(0, f.speedT - dt);
    f.shieldT = Math.max(0, f.shieldT - dt);
    f.frenzyT = Math.max(0, f.frenzyT - dt);
    f.autoT = Math.max(0, f.autoT - dt);
    f.dashT = Math.max(0, f.dashT - dt);
    f.ramCd = Math.max(0, f.ramCd - dt);
    if (f.burnT > 0) { f.burnT -= dt; if (Math.random() < dt * 6) this.damage(f, 2, null); }
    if (f.reloadT > 0) {
      f.reloadT -= dt;
      if (f.reloadT <= 0) { f.ammo = f.def.weapon.ammo; if (f.isPlayer) audio.sfx("pickup"); }
    }
    // knockback decay
    if (Math.abs(f.kbx) > 1 || Math.abs(f.kby) > 1) {
      this.moveFighter(f, f.kbx, f.kby, dt);
      f.kbx *= Math.pow(0.0008, dt); f.kby *= Math.pow(0.0008, dt);
    }
    // rickshaw ram
    if (f.autoT > 0 && f.ramCd <= 0) {
      for (const o of this.fighters) {
        if (o === f || o.dead) continue;
        if (dist2(o.x, o.y, f.x, f.y) < 26 * 26) {
          this.damage(o, 30, f, 340, Math.atan2(o.y - f.y, o.x - f.x));
          f.ramCd = 0.5;
          this.emojiBurst(o.x, o.y - 10, ["🛺", "💥"], 3);
          break;
        }
      }
    }
    // trap triggers
    for (let i = this.traps.length - 1; i >= 0; i--) {
      const t = this.traps[i];
      if (t.owner === f.id || f.dead) continue;
      if (dist2(t.x, t.y, f.x, f.y) < 18 * 18) {
        this.traps.splice(i, 1);
        const owner = this.fighters.find((o) => o.id === t.owner) ?? null;
        if (t.kind === "banana") {
          f.stunT = Math.max(f.stunT, 1.3);
          f.kbx += rnd(-260, 260); f.kby += rnd(-260, 260);
          this.damage(f, 8, owner);
          this.float(f.x, f.y - 36, "SLIPPED! 🍌", "#ffe066", 11);
          audio.sfx("stun");
          this.emojiBurst(f.x, f.y - 8, ["🍌", "😵"], 3);
        } else {
          this.explode(t.x, t.y, 70, 34, t.owner, "#9ef01a", ["🐸", "💥", "😹"]);
        }
      }
    }
    // dead handling
    if (f.dead) {
      f.deadT += dt;
      f.respawnT -= dt;
      if (f.respawnT <= 0 && !this.over) {
        f.dead = false; f.hp = f.maxHp; f.ammo = f.def.weapon.ammo;
        f.reloadT = 0; f.kbx = f.kby = 0; f.spCd = Math.min(f.spCd, 2);
        if (f.isPlayer) f.shieldT = 1.25;
        this.respawnPos(f);
        this.ring(f.x, f.y, "#24e0ff", 36);
        this.burst(f.x, f.y - 8, "#24e0ff", 12, 180);
        if (f.isPlayer) { audio.sfx("start"); this.setBanner("WAAPAS AA GAYA! 😤", 1.2); }
      }
    }
  }

  private updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      const steps = 3;
      let alive = true;
      for (let s = 0; s < steps && alive; s++) {
        b.x += (b.vx * dt) / steps; b.y += (b.vy * dt) / steps;
        b.dist += (Math.hypot(b.vx, b.vy) * dt) / steps;
        if (b.dist > b.range) { alive = false; break; }
        const blockedByCover = b.pierce ? this.map.wallAt(b.x, b.y) : this.map.solidAt(b.x, b.y);
        if (blockedByCover) {
          this.burst(b.x, b.y, "#c9c1d9", 4, 90);
          if (b.splash > 0) this.explode(b.x, b.y, b.splash, b.dmg, b.owner, "#d4a373", ["☕", "💨"]);
          alive = false; break;
        }
        for (const f of this.fighters) {
          if (f.dead || f.id === b.owner || b.hit.has(f.id)) continue;
          const hb = f.isPlayer && this.keys.has("control") ? R - 3 : R;
          if (dist2(f.x, f.y - 6, b.x, b.y) < (hb + b.size) * (hb + b.size)) {
            const owner = this.fighters.find((o) => o.id === b.owner) ?? null;
            this.damage(f, b.dmg, owner, 60, Math.atan2(b.vy, b.vx));
            if (b.splash > 0) { f.burnT = 1; this.explode(b.x, b.y, b.splash, b.dmg * 0.5, b.owner, "#d4a373", ["☕"]); alive = false; break; }
            if (b.pierce) { b.hit.add(f.id); } else { alive = false; break; }
          }
        }
      }
      if (!alive) this.bullets.splice(i, 1);
    }
  }

  private updateGrenades(dt: number) {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const gr = this.grenades[i];
      gr.t += dt;
      const nx = gr.x + gr.vx * dt, ny = gr.y + gr.vy * dt;
      if (this.map.wallAt(nx, ny)) { gr.vx *= -0.4; gr.vy *= -0.4; }
      else { gr.x = nx; gr.y = ny; }
      gr.vx *= Math.pow(0.15, dt); gr.vy *= Math.pow(0.15, dt);
      if (gr.t >= gr.fuse) {
        this.grenades.splice(i, 1);
        if (gr.kind === "chai") this.explode(gr.x, gr.y, 78, 38, gr.owner, "#d4a373", ["☕", "🫖", "💨"]);
        else this.explode(gr.x, gr.y, 88, 48, gr.owner, "#ffdd57", ["💥", "😂", "💀", "🤣"]);
      }
    }
  }

  private endMatch() {
    if (this.over) return;
    this.over = true;
    audio.sfx("over");
    audio.stopMusic();
    const rows: ScoreRow[] = this.fighters
      .map((f) => ({ name: f.name, charId: f.def.id, kills: f.kills, deaths: f.deaths, score: f.score, isPlayer: f.isPlayer }))
      .sort((a, b) => b.score - a.score || b.kills - a.kills);
    const playerRank = rows.findIndex((r) => r.isPlayer) + 1;
    const p = this.fighters[0];
    setTimeout(() => {
      if (!this.destroyed) this.cb.onGameOver({ rows, playerRank, playerScore: p.score, playerKills: p.kills, mvpName: rows[0].name });
    }, 900);
  }

  // ---------- main loop ----------
  private loop = (now: number) => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = Math.min((now - this.last) / 1000, 0.035);
    this.last = now;
    if (this.paused) { this.render(); return; }
    if (this.hitstop > 0) { this.hitstop -= dt; dt *= 0.12; }

    if (!this.over) {
      this.elapsed += dt;
      this.time -= dt;
      this.hintT -= dt;
      if (this.time <= 0) { this.time = 0; this.endMatch(); }
      this.pickupT -= dt;
      if (this.pickupT <= 0) { this.pickupT = 4.5; this.spawnPickup(); }

      const p = this.fighters[0];
      this.updatePlayer(p, dt);
      for (let i = 1; i < this.fighters.length; i++) this.updateBot(this.fighters[i], dt);
      for (const f of this.fighters) this.updateFighterCommon(f, dt);
      this.updateBullets(dt);
      this.updateGrenades(dt);
    }

    // fx updates
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.life += dt;
      pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.vy += pt.grav * dt;
      if (pt.life >= pt.max) this.particles.splice(i, 1);
    }
    for (let i = this.floats.length - 1; i >= 0; i--) {
      const ft = this.floats[i];
      ft.t += dt; ft.y -= 34 * dt;
      if (ft.t > 1) this.floats.splice(i, 1);
    }
    for (let i = this.feed.length - 1; i >= 0; i--) { this.feed[i].t += dt; if (this.feed[i].t > 4.5) this.feed.splice(i, 1); }
    for (let i = this.decoys.length - 1; i >= 0; i--) { this.decoys[i].t += dt; if (this.decoys[i].t > 3) this.decoys.splice(i, 1); }
    for (const t of this.traps) t.life -= dt;
    this.traps = this.traps.filter((t) => t.life > 0);
    for (const pk of this.pickups) pk.bob += dt;
    this.banner.t -= dt;
    this.hurtT = Math.max(0, this.hurtT - dt);
    this.shake = Math.max(0, this.shake - dt * 26);

    // camera
    const p = this.fighters[0];
    const vw = this.w / this.zoom, vh = this.h / this.zoom;
    const tx = clamp(p.x, vw / 2, WORLD_W - vw / 2);
    const ty = clamp(p.y, vh / 2, WORLD_H - vh / 2);
    this.camX += (tx - this.camX) * Math.min(1, dt * 8);
    this.camY += (ty - this.camY) * Math.min(1, dt * 8);

    this.render();
  };

  // ---------- render ----------
  private render() {
    const g = this.g;
    g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    g.imageSmoothingEnabled = false;
    g.fillStyle = "#0b0614";
    g.fillRect(0, 0, this.w, this.h);

    const sx = this.shake > 0 ? rnd(-this.shake, this.shake) : 0;
    const sy = this.shake > 0 ? rnd(-this.shake, this.shake) : 0;
    g.save();
    g.translate(this.w / 2 + sx, this.h / 2 + sy);
    g.scale(this.zoom, this.zoom);
    g.translate(-this.camX, -this.camY);

    // map
    const vw = this.w / this.zoom, vh = this.h / this.zoom;
    const mx = clamp(this.camX - vw / 2 - 40, 0, WORLD_W), my = clamp(this.camY - vh / 2 - 40, 0, WORLD_H);
    const mw = Math.min(vw + 80, WORLD_W - mx), mh = Math.min(vh + 80, WORLD_H - my);
    g.drawImage(this.map.canvas, mx, my, mw, mh, mx, my, mw, mh);

    // ground items: traps, pickups
    for (const t of this.traps) {
      g.save(); g.translate(t.x, t.y);
      g.fillStyle = "rgba(0,0,0,0.25)"; g.beginPath(); g.ellipse(0, 3, 9, 4, 0, 0, 7); g.fill();
      g.font = "14px serif"; g.textAlign = "center"; g.textBaseline = "middle";
      g.fillText(t.memoji, 0, 0);
      if (t.life < 3 && Math.sin(t.life * 10) > 0) { g.strokeStyle = "#ff3d3d"; g.strokeRect(-9, -9, 18, 18); }
      g.restore();
    }
    for (const pk of this.pickups) {
      const bob = Math.sin(pk.bob * 3) * 3;
      g.save(); g.translate(pk.x, pk.y + bob - 6);
      g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 12 - bob, 8, 3, 0, 0, 7); g.fill();
      if (pk.kind === "chai") {
        g.fillStyle = "#e8e4da"; g.fillRect(-5, -7, 10, 13);
        g.fillStyle = "#c9782a"; g.fillRect(-4, -4, 8, 9);
        g.fillStyle = "#fff"; g.globalAlpha = 0.7; g.fillRect(-2, -11, 1, 3); g.fillRect(1, -12, 1, 4); g.globalAlpha = 1;
      } else if (pk.kind === "data") {
        g.fillStyle = "#1e3a8a"; g.fillRect(-7, -6, 14, 11);
        g.fillStyle = "#6db4ff"; g.fillRect(-5, -4, 10, 5);
        g.fillStyle = "#ffd400"; g.fillRect(-2, 2, 4, 2);
      } else {
        g.fillStyle = "#2a2438"; g.fillRect(-8, -3, 16, 8);
        g.fillStyle = "#24e0ff"; g.fillRect(-6, -1, 3, 3); g.fillRect(3, -1, 3, 3);
        g.fillStyle = "#8d99ae"; g.fillRect(-6, -9, 2, 6); g.fillRect(4, -9, 2, 6);
      }
      g.restore();
    }
    // decoys (fake corpses)
    for (const d of this.decoys) {
      g.save(); g.translate(d.x, d.y);
      drawDeadSprite(g, d.def, Math.min(d.t * 0.4, 0.6));
      g.restore();
    }

    // y-sorted entities
    type Ent = { y: number; draw: () => void };
    const ents: Ent[] = [];
    for (const cv of this.map.covers) ents.push({ y: cv.ty * TILE + TILE, draw: () => drawCover(g, cv, this.elapsed) });
    for (const f of this.fighters) {
      const ff = f;
      ents.push({
        y: ff.y + 16, draw: () => {
          g.save();
          g.translate(ff.x, ff.y);
          if (ff.dead) {
            drawDeadSprite(g, ff.def, ff.deadT);
            g.restore();
            return;
          }
          let alpha = 1;
          if (ff.invisT > 0) alpha = ff.isPlayer ? 0.35 : 0.06;
          else if (ff.def.id === "ghost") alpha = ff.isPlayer ? 0.85 : 0.55;
          // rickshaw under fighter
          if (ff.autoT > 0) {
            g.save(); g.globalAlpha = alpha;
            g.fillStyle = "#ffd400"; g.fillRect(-16, 2, 32, 12);
            g.fillStyle = "#1f9e4c"; g.fillRect(-16, 2, 32, 3);
            g.fillStyle = "#111"; g.beginPath(); g.arc(-10, 15, 5, 0, 7); g.fill(); g.beginPath(); g.arc(10, 15, 5, 0, 7); g.fill();
            g.restore();
          }
          if (ff.hitFlash > 0) { g.filter = "brightness(2.2)"; }
          drawFighterSprite(g, ff.def, { frame: ff.frame, moving: ff.moving, flip: ff.flip, crouch: ff.isPlayer && this.keys.has("control"), alpha, aim: ff.aim, time: this.elapsed + ff.id });
          g.filter = "none";
          // shield ring
          if (ff.shieldT > 0) {
            g.strokeStyle = "rgba(125,255,155,0.8)"; g.lineWidth = 2;
            g.beginPath(); g.arc(0, -6, 20 + Math.sin(this.elapsed * 6) * 2, 0, 7); g.stroke();
          }
          if (ff.stunT > 0) {
            g.font = "10px serif"; g.textAlign = "center";
            g.fillText("💫", Math.sin(this.elapsed * 8) * 8, -30);
          }
          // name + hp bar (not for invisible enemies)
          if (alpha > 0.2) {
            g.globalAlpha = Math.min(1, alpha + 0.3);
            g.fillStyle = "rgba(10,6,20,0.6)";
            g.fillRect(-16, -36, 32, 4);
            const pct = ff.hp / ff.maxHp;
            g.fillStyle = ff.isPlayer ? "#7dff9b" : pct > 0.5 ? "#ffd400" : "#ff5d5d";
            g.fillRect(-15, -35, 30 * clamp(pct, 0, 1), 2);
            g.font = "600 7px Rubik, sans-serif"; g.textAlign = "center";
            g.fillStyle = ff.isPlayer ? "#a8ffbe" : "#e8ddff";
            g.fillText(ff.name, 0, -39);
            g.globalAlpha = 1;
          }
          g.restore();
        },
      });
    }
    for (const gr of this.grenades) {
      const grr = gr;
      ents.push({
        y: grr.y + 8, draw: () => {
          const arc = Math.sin((grr.t / grr.fuse) * Math.PI) * 22;
          g.save(); g.translate(grr.x, grr.y);
          g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 2, 6, 3, 0, 0, 7); g.fill();
          g.translate(0, -arc);
          g.font = "13px serif"; g.textAlign = "center"; g.textBaseline = "middle";
          g.fillText(grr.kind === "chai" ? "🫖" : ["💣", "🤯", "💥"][Math.floor(grr.t * 8) % 3], 0, 0);
          g.restore();
        },
      });
    }
    ents.sort((a, b) => a.y - b.y);
    for (const e of ents) e.draw();

    // bullets
    for (const b of this.bullets) {
      g.save();
      g.translate(b.x, b.y);
      g.rotate(Math.atan2(b.vy, b.vx));
      g.fillStyle = b.color;
      g.shadowColor = b.color; g.shadowBlur = 6;
      g.fillRect(-b.size * 1.6, -b.size / 2, b.size * 3.2, b.size);
      g.restore();
    }
    // particles
    for (const pt of this.particles) {
      const lt = pt.life / pt.max;
      g.globalAlpha = 1 - lt;
      if (pt.kind === "rect") {
        g.fillStyle = pt.color;
        g.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
      } else if (pt.kind === "emoji") {
        g.font = `${pt.size}px serif`; g.textAlign = "center";
        g.fillText(pt.text!, pt.x, pt.y);
      } else {
        g.strokeStyle = pt.color; g.lineWidth = 3 * (1 - lt);
        g.beginPath(); g.arc(pt.x, pt.y, pt.size * (0.3 + lt * 0.9), 0, 7); g.stroke();
      }
      g.globalAlpha = 1;
    }
    // floats
    for (const ft of this.floats) {
      g.globalAlpha = 1 - ft.t;
      g.font = `800 ${ft.size}px Rubik, sans-serif`;
      g.textAlign = "center";
      g.strokeStyle = "rgba(10,6,20,0.8)"; g.lineWidth = 3;
      g.strokeText(ft.text, ft.x, ft.y);
      g.fillStyle = ft.color;
      g.fillText(ft.text, ft.x, ft.y);
      g.globalAlpha = 1;
    }
    g.restore();

    this.renderHUD();
  }

  private renderHUD() {
    const g = this.g;
    const p = this.fighters[0];
    g.textBaseline = "alphabetic";

    // hurt vignette
    if (this.hurtT > 0 || (p.hp < p.maxHp * 0.3 && !p.dead)) {
      const a = this.hurtT > 0 ? this.hurtT * 1.6 : 0.18 + Math.sin(this.elapsed * 5) * 0.06;
      const grad = g.createRadialGradient(this.w / 2, this.h / 2, this.h * 0.35, this.w / 2, this.h / 2, this.h * 0.75);
      grad.addColorStop(0, "rgba(200,0,30,0)");
      grad.addColorStop(1, `rgba(200,0,30,${clamp(a, 0, 0.5)})`);
      g.fillStyle = grad;
      g.fillRect(0, 0, this.w, this.h);
    }

    // ---- top-left: health ----
    const hx = 14, hy = 14;
    g.fillStyle = "rgba(12,7,24,0.75)";
    g.fillRect(hx, hy, 224, 58);
    g.strokeStyle = "rgba(255,255,255,0.15)"; g.lineWidth = 2;
    g.strokeRect(hx, hy, 224, 58);
    // mini portrait
    g.save();
    g.translate(hx + 26, hy + 38);
    g.scale(1.15, 1.15);
    drawFighterSprite(g, p.def, { frame: 0, moving: false, flip: false, crouch: false, alpha: 1, aim: -0.3, time: this.elapsed });
    g.restore();
    g.font = "700 11px Rubik, sans-serif";
    g.fillStyle = "#e8ddff"; g.textAlign = "left";
    g.fillText(p.def.name.toUpperCase(), hx + 52, hy + 16);
    // hp bar
    const hpw = 158;
    g.fillStyle = "#241535"; g.fillRect(hx + 52, hy + 23, hpw, 13);
    const pct = clamp(p.hp / p.maxHp, 0, 1);
    const hpColor = pct > 0.55 ? "#7dff9b" : pct > 0.28 ? "#ffd400" : "#ff5d5d";
    g.fillStyle = hpColor;
    g.fillRect(hx + 52, hy + 23, hpw * pct, 13);
    g.fillStyle = "rgba(255,255,255,0.25)"; g.fillRect(hx + 52, hy + 23, hpw * pct, 4);
    g.font = "800 10px Rubik, sans-serif"; g.fillStyle = "#0b0614"; g.textAlign = "center";
    g.fillText(`${Math.max(0, Math.ceil(p.hp))} / ${p.maxHp}`, hx + 52 + hpw / 2, hy + 33);
    // streak + score
    g.textAlign = "left"; g.fillStyle = "#ffd400"; g.font = "700 11px Rubik, sans-serif";
    g.fillText(`⭐ ${p.score}`, hx + 52, hy + 50);
    if (p.streak >= 2) { g.fillStyle = "#ff7b4d"; g.fillText(`🔥 x${p.streak}`, hx + 130, hy + 50); }

    // ---- top-center: timer + kill feed ----
    const min = Math.floor(this.time / 60), sec = Math.floor(this.time % 60);
    g.font = "800 18px 'Press Start 2P', monospace";
    g.textAlign = "center";
    g.fillStyle = "rgba(12,7,24,0.75)";
    g.fillRect(this.w / 2 - 62, 10, 124, 34);
    g.fillStyle = this.time < 20 ? "#ff5d5d" : "#fff";
    g.font = "16px 'Press Start 2P', monospace";
    g.fillText(`${min}:${sec.toString().padStart(2, "0")}`, this.w / 2, 34);
    let fy = 56;
    g.font = "600 11px Rubik, sans-serif";
    for (const item of this.feed) {
      const alpha = clamp(1 - (item.t - 3.5), 0, 1);
      g.globalAlpha = alpha * 0.9;
      const tw = g.measureText(item.text).width;
      g.fillStyle = "rgba(12,7,24,0.7)";
      g.fillRect(this.w / 2 - tw / 2 - 8, fy - 12, tw + 16, 17);
      g.fillStyle = item.text.startsWith("YOU") ? "#7dff9b" : "#e8ddff";
      g.fillText(item.text, this.w / 2, fy);
      g.globalAlpha = 1;
      fy += 20;
    }

    // ---- banner ----
    if (this.banner.t > 0) {
      const bt = clamp(this.banner.t, 0, 1);
      g.globalAlpha = bt;
      g.font = "800 26px Rubik, sans-serif";
      g.textAlign = "center";
      g.strokeStyle = "rgba(10,6,20,0.9)"; g.lineWidth = 5;
      const by = this.h * 0.3 - (1 - bt) * 20;
      g.strokeText(this.banner.text, this.w / 2, by);
      g.fillStyle = "#ffd400";
      g.fillText(this.banner.text, this.w / 2, by);
      g.globalAlpha = 1;
    }

    // ---- top-right: minimap ----
    const mmW = MW * 3, mmH = MH * 3;
    const mmx = this.w - mmW - 12, mmy = 12;
    g.globalAlpha = 0.9;
    g.drawImage(this.map.mini, mmx, mmy);
    g.strokeStyle = "rgba(255,255,255,0.2)"; g.strokeRect(mmx, mmy, mmW, mmH);
    for (const f of this.fighters) {
      if (f.dead) continue;
      if (!f.isPlayer && f.invisT > 0.2) continue;
      g.fillStyle = f.isPlayer ? "#7dff9b" : "#ff5d5d";
      const dx = mmx + (f.x / WORLD_W) * mmW, dy = mmy + (f.y / WORLD_H) * mmH;
      g.fillRect(dx - 2, dy - 2, 4, 4);
    }
    for (const pk of this.pickups) {
      g.fillStyle = pk.kind === "chai" ? "#ffb84d" : pk.kind === "data" ? "#6db4ff" : "#24e0ff";
      g.fillRect(mmx + (pk.x / WORLD_W) * mmW - 1, mmy + (pk.y / WORLD_H) * mmH - 1, 3, 3);
    }
    g.globalAlpha = 1;

    // ---- bottom-right: ammo + special ----
    const ax = this.w - 14, ay = this.h - 14;
    g.fillStyle = "rgba(12,7,24,0.75)";
    g.fillRect(ax - 190, ay - 64, 190, 64);
    g.strokeStyle = "rgba(255,255,255,0.15)"; g.strokeRect(ax - 190, ay - 64, 190, 64);
    g.textAlign = "right";
    if (p.reloadT > 0) {
      g.fillStyle = "#ffd400"; g.font = "700 13px Rubik, sans-serif";
      g.fillText("RELOADING…", ax - 72, ay - 38);
      const rp = 1 - p.reloadT / p.def.weapon.reload;
      g.fillStyle = "#241535"; g.fillRect(ax - 180, ay - 30, 110, 8);
      g.fillStyle = "#ffd400"; g.fillRect(ax - 180, ay - 30, 110 * rp, 8);
    } else {
      g.fillStyle = p.ammo === 0 ? "#ff5d5d" : "#fff";
      g.font = "24px 'Press Start 2P', monospace";
      g.fillText(`${p.ammo}`, ax - 100, ay - 28);
      g.font = "600 11px Rubik, sans-serif";
      g.fillStyle = "#9d8fc0";
      g.fillText(`/ ${p.def.weapon.ammo}`, ax - 72, ay - 28);
    }
    g.font = "600 10px Rubik, sans-serif";
    g.fillStyle = "#9d8fc0";
    g.fillText(p.def.weapon.name + (this.isTouch ? "" : "  •  R reload"), ax - 72, ay - 10);
    // special cooldown circle
    const scx = ax - 36, scy = ay - 32, rad = 22;
    g.beginPath(); g.arc(scx, scy, rad, 0, 7);
    g.fillStyle = "rgba(30,18,52,0.95)"; g.fill();
    const cd = p.spCd / p.def.specialCd;
    if (cd > 0) {
      g.beginPath(); g.moveTo(scx, scy);
      g.arc(scx, scy, rad, -Math.PI / 2, -Math.PI / 2 + (1 - cd) * Math.PI * 2);
      g.closePath(); g.fillStyle = "rgba(255,61,139,0.4)"; g.fill();
    } else {
      g.beginPath(); g.arc(scx, scy, rad, 0, 7);
      g.fillStyle = `rgba(255,61,139,${0.5 + Math.sin(this.elapsed * 5) * 0.2})`; g.fill();
    }
    g.strokeStyle = cd > 0 ? "#4a3d59" : "#ff3d8b"; g.lineWidth = 2;
    g.beginPath(); g.arc(scx, scy, rad, 0, 7); g.stroke();
    g.font = "17px serif"; g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText(p.def.emoji, scx, scy + 1);
    g.textBaseline = "alphabetic";
    if (cd > 0) {
      g.font = "700 10px Rubik, sans-serif"; g.fillStyle = "#fff";
      g.fillText(Math.ceil(p.spCd).toString(), scx, scy + rad + 12);
    } else if (!this.isTouch) {
      g.font = "700 8px Rubik, sans-serif"; g.fillStyle = "#ff9ecb";
      g.fillText("RMB", scx, scy + rad + 10);
    }

    // ---- touch controls ----
    if (this.isTouch) {
      g.globalAlpha = 0.4;
      const ms = this.moveStick;
      const mbx = ms.id !== -1 ? ms.bx : 90, mby = ms.id !== -1 ? ms.by : this.h - 100;
      g.strokeStyle = "#fff"; g.lineWidth = 2;
      g.beginPath(); g.arc(mbx, mby, 46, 0, 7); g.stroke();
      g.fillStyle = "#fff";
      g.beginPath(); g.arc(mbx + ms.dx * 0.75, mby + ms.dy * 0.75, 20, 0, 7); g.fill();
      const as = this.aimStick;
      if (as.id !== -1) {
        g.strokeStyle = "#ff3d8b";
        g.beginPath(); g.arc(as.bx, as.by, 46, 0, 7); g.stroke();
        g.fillStyle = "#ff3d8b";
        g.beginPath(); g.arc(as.bx + as.dx * 0.75, as.by + as.dy * 0.75, 20, 0, 7); g.fill();
      } else {
        g.font = "600 11px Rubik, sans-serif"; g.textAlign = "center"; g.fillStyle = "#fff";
        g.fillText("touch right side to aim + fire", this.w - 130, this.h - 110);
      }
      g.globalAlpha = 0.75;
      // special button
      g.beginPath(); g.arc(this.spBtn.x, this.spBtn.y, this.spBtn.r, 0, 7);
      g.fillStyle = p.spCd > 0 ? "rgba(40,25,60,0.8)" : "rgba(255,61,139,0.75)"; g.fill();
      g.font = "22px serif"; g.textAlign = "center"; g.textBaseline = "middle";
      g.fillText(p.def.emoji, this.spBtn.x, this.spBtn.y);
      g.textBaseline = "alphabetic";
      g.globalAlpha = 1;
    }

    // ---- hint ----
    if (this.hintT > 0 && !this.isTouch) {
      g.globalAlpha = clamp(this.hintT, 0, 1) * 0.85;
      g.font = "600 12px Rubik, sans-serif"; g.textAlign = "center";
      g.fillStyle = "rgba(12,7,24,0.8)";
      g.fillRect(this.w / 2 - 240, this.h - 44, 480, 26);
      g.fillStyle = "#c9b8ff";
      g.fillText("WASD move • Mouse aim / auto-fire on target • RMB special • Shift sprint • Tab score", this.w / 2, this.h - 27);
      g.globalAlpha = 1;
    }

    // ---- respawn overlay ----
    if (p.dead) {
      g.fillStyle = "rgba(10,5,18,0.55)";
      g.fillRect(0, 0, this.w, this.h);
      g.textAlign = "center";
      g.font = "800 30px Rubik, sans-serif";
      g.fillStyle = "#ff5d5d";
      g.fillText("ELIMINATED 💀", this.w / 2, this.h / 2 - 30);
      g.font = "700 16px Rubik, sans-serif";
      g.fillStyle = "#e8ddff";
      g.fillText(`respawning in ${Math.max(0, p.respawnT).toFixed(1)}s`, this.w / 2, this.h / 2 + 2);
    }

    // ---- scoreboard (Tab) ----
    if (this.showBoard || this.over) this.drawScoreboard();
  }

  private drawScoreboard() {
    const g = this.g;
    const rows = [...this.fighters].sort((a, b) => b.score - a.score || b.kills - a.kills);
    const bw = Math.min(480, this.w - 30), bh = 66 + rows.length * 26;
    const bx = this.w / 2 - bw / 2, by = Math.max(60, this.h / 2 - bh / 2);
    g.fillStyle = "rgba(10,6,22,0.92)";
    g.fillRect(bx, by, bw, bh);
    g.strokeStyle = "#ff3d8b"; g.lineWidth = 2; g.strokeRect(bx, by, bw, bh);
    g.font = "12px 'Press Start 2P', monospace"; g.textAlign = "center"; g.fillStyle = "#ffd400";
    g.fillText("SCOREBOARD", this.w / 2, by + 26);
    g.font = "600 11px Rubik, sans-serif"; g.textAlign = "left"; g.fillStyle = "#9d8fc0";
    g.fillText("PLAYER", bx + 44, by + 48);
    g.textAlign = "right";
    g.fillText("K", bx + bw - 120, by + 48);
    g.fillText("D", bx + bw - 80, by + 48);
    g.fillText("SCORE", bx + bw - 18, by + 48);
    rows.forEach((f, i) => {
      const y = by + 66 + i * 26;
      if (f.isPlayer) { g.fillStyle = "rgba(125,255,155,0.12)"; g.fillRect(bx + 6, y - 16, bw - 12, 22); }
      g.textAlign = "left";
      g.fillStyle = i === 0 ? "#ffd400" : "#e8ddff";
      g.font = "700 12px Rubik, sans-serif";
      g.fillText(`${i + 1}. ${i === 0 ? "👑 " : ""}${f.name}`, bx + 18, y);
      g.font = "600 10px Rubik, sans-serif"; g.fillStyle = "#9d8fc0";
      g.fillText(f.def.name, bx + 190, y);
      g.textAlign = "right"; g.font = "700 12px Rubik, sans-serif"; g.fillStyle = "#e8ddff";
      g.fillText(`${f.kills}`, bx + bw - 120, y);
      g.fillText(`${f.deaths}`, bx + bw - 80, y);
      g.fillStyle = "#ffd400";
      g.fillText(`${f.score}`, bx + bw - 18, y);
    });
  }
}
