import { useCallback, useEffect, useState } from "react";
import { MainMenu, CharacterSelect, HowToPlay, Settings } from "./components/screens";
import { GameScreen } from "./components/GameScreen";
import { loadSettings, saveSettings } from "./game/highscores";
import type { StoredSettings } from "./game/highscores";

type Screen = "menu" | "chars" | "charsView" | "howto" | "settings" | "game";

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [selectedChar, setSelectedChar] = useState("rager");
  const [settings, setSettings] = useState<StoredSettings>(loadSettings);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  const nav = useCallback((s: string) => setScreen(s as Screen), []);

  return (
    <div className="w-full h-full fixed inset-0">
      {screen === "menu" && <MainMenu onNav={nav} />}
      {(screen === "chars" || screen === "charsView") && (
        <CharacterSelect
          selected={selectedChar}
          onSelect={setSelectedChar}
          onPlay={() => setScreen("game")}
          onBack={() => setScreen("menu")}
          viewOnly={screen === "charsView"}
        />
      )}
      {screen === "howto" && <HowToPlay onBack={() => setScreen("menu")} />}
      {screen === "settings" && (
        <Settings settings={settings} onChange={setSettings} onBack={() => setScreen("menu")} />
      )}
      {screen === "game" && (
        <GameScreen
          charId={selectedChar}
          settings={settings}
          onSettingsChange={setSettings}
          onQuit={() => setScreen("menu")}
        />
      )}
    </div>
  );
}
